package com.tvaalex.alexcraft.items.enchants;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnumEnchantmentType;

public class EnchantmentNocturnalAbility extends Enchantment{

	protected EnchantmentNocturnalAbility(int p_i1926_1_, int p_i1926_2_) {
		super(p_i1926_1_, p_i1926_2_, EnumEnchantmentType.armor_head);
		this.setName("Nocturnal Ability");
		// TODO Auto-generated constructor stub
	}
	
	public int getMaxLevel() {
		return 1;
	}

}
