package com.tvaalex.alexcraft.items.enchants;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnumEnchantmentType;

public class EnchantmentRangex extends Enchantment{

	protected EnchantmentRangex(int p_i1926_1_, int p_i1926_2_) {
		super(p_i1926_1_, p_i1926_2_, EnumEnchantmentType.breakable);
		this.setName("Rangex");
		// TODO Auto-generated constructor stub
	}
	
	public int getMaxLevel() {
		return 3;
	}

}
