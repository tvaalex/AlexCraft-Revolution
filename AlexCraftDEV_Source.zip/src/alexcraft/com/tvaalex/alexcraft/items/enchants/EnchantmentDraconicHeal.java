package com.tvaalex.alexcraft.items.enchants;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnumEnchantmentType;

public class EnchantmentDraconicHeal extends Enchantment{

	protected EnchantmentDraconicHeal(int p_i1926_1_, int p_i1926_2_) {
		super(p_i1926_1_, p_i1926_2_, EnumEnchantmentType.armor_torso);
		this.setName("Draconic Health");
		// TODO Auto-generated constructor stub
	}
	
	public int getMaxLevel() {
		return 6;
	}

}
