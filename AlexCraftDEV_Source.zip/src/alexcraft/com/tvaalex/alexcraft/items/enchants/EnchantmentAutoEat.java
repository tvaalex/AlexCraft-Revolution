package com.tvaalex.alexcraft.items.enchants;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnumEnchantmentType;

public class EnchantmentAutoEat extends Enchantment {

	protected EnchantmentAutoEat(int p_i1926_1_, int p_i1926_2_) {
		super(p_i1926_1_, p_i1926_2_, EnumEnchantmentType.armor_head);
		// TODO Auto-generated constructor stub
	}
	
	public int getMaxLevel() {
		return 1;
	}

}
