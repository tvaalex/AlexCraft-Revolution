package com.tvaalex.alexcraft.items.enchants;

import net.minecraft.enchantment.Enchantment;

public class EnchantmentRegistry {
	
	public static final Enchantment nocturnalAbility = new EnchantmentNocturnalAbility(84, 10);
	public static final Enchantment draconicHeal = new EnchantmentDraconicHeal(85, 34);
	public static final Enchantment agility = new EnchantmentAgility(86, 6);
	public static final Enchantment slimyJump = new EnchantmentSlimyJump(87, 15);
	public static final Enchantment rangex = new EnchantmentRangex(88, 18);
	public static final Enchantment deeper = new EnchantmentDeeper(89, 18);
	public static final Enchantment autoEat = new EnchantmentAutoEat(90, 21);


}
