package com.tvaalex.alexcraft.items.electronical;

import com.tvaalex.alexcraft.AlexCraft;
import com.tvaalex.alexcraft.DarkSteelThings;
import com.tvaalex.alexcraft.ElekiumThings;
import com.tvaalex.alexcraft.SteelThings;
import com.tvaalex.alexcraft.items.ACItem;
import com.tvaalex.alexcraft.items.tools.SciFiTechPick;
import com.tvaalex.alexcraft.items.tools.SciFiTechSword;

import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.util.EnumHelper;

public class ElectronicalRegistry {
	
	public static Item computerCardSciFi;
	public static Item computerCardStorage;
	
	//SCI-FI TECH
		public static Item sciFiTechSword;
		public static Item sciFiTechPickaxe;
		public static Item sciFiTechBow;
		public static Item sciFiTechArrow;
		public static final Item.ToolMaterial sciFiTechToolMaterial = EnumHelper.addToolMaterial("SciFiTechToolMaterial", 4, 2720, 9.0F, 7.5F, 1500); 
	
	public static void LoadAll() {
		GameRegistry.registerItem(computerCardSciFi = new ACItem().setUnlocalizedName("ComputerCardSciFi").setTextureName(AlexCraft.modid + ":ComputerCardSciFi").setCreativeTab(AlexCraft.tabAlexCraftModElectronical), computerCardSciFi.getUnlocalizedName().substring(5));
		GameRegistry.addRecipe(new ItemStack(computerCardSciFi), new Object[] {"XXX", "XYX", "XXZ", 'X', DarkSteelThings.itemDarkSteelIngot, 'Y', ElekiumThings.itemAdvancedElekiumCircut, 'Z', ElekiumThings.itemElekiumIngot});
		
		GameRegistry.registerItem(computerCardStorage = new ACItem().setUnlocalizedName("ComputerCardStorage").setTextureName(AlexCraft.modid + ":ComputerCardStorage").setCreativeTab(AlexCraft.tabAlexCraftModElectronical), computerCardStorage.getUnlocalizedName().substring(5));
		GameRegistry.addRecipe(new ItemStack(computerCardSciFi), new Object[] {"XYX", "YZY", "XYX", 'X', SteelThings.itemSteelIngot, 'Y', ElekiumThings.itemBasicElekiumCircut, 'Z', Blocks.chest});
		
		//SCI-FI TECH
		GameRegistry.registerItem(sciFiTechSword = new SciFiTechSword("SciFiTechSword", sciFiTechToolMaterial).setCreativeTab(AlexCraft.tabAlexCraftModElectronical), sciFiTechSword.getUnlocalizedName().substring(5));
		GameRegistry.addRecipe(new ItemStack(sciFiTechSword), new Object[] {" X ", " X ", "ZYZ", 'X', DarkSteelThings.itemSuperDarkSteelIngot, 'Y', computerCardSciFi, 'Z', DarkSteelThings.itemDarkSteelIngot});
		GameRegistry.registerItem(sciFiTechPickaxe = new SciFiTechPick("SciFiTechPickaxe", sciFiTechToolMaterial).setCreativeTab(AlexCraft.tabAlexCraftModElectronical), sciFiTechPickaxe.getUnlocalizedName().substring(5));
		GameRegistry.addRecipe(new ItemStack(sciFiTechPickaxe), new Object[] {"XYX", " Z ", " Z ", 'X', DarkSteelThings.itemSuperDarkSteelIngot, 'Y', computerCardSciFi, 'Z', DarkSteelThings.itemDarkSteelIngot});
	}

}
