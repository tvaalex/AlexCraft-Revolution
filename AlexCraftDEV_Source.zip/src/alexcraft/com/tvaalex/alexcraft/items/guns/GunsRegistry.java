package com.tvaalex.alexcraft.items.guns;

import com.tvaalex.alexcraft.AlexCraft;
import com.tvaalex.alexcraft.items.ACItem;

import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.item.Item;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EntityDamageSourceIndirect;

public class GunsRegistry {
	//Ammos
	public static Item itemSteelPistolAmmo;
	//Guns
	public static Item pistol;
	
	public static void LoadAll() {
		//Ammos
		GameRegistry.registerItem(itemSteelPistolAmmo = new ACItem().setUnlocalizedName("ItemSteelPistolAmmo"), itemSteelPistolAmmo.getUnlocalizedName().substring(5));
		//Guns
		GameRegistry.registerItem(pistol = new Pistol().setUnlocalizedName("Pistol").setTextureName(AlexCraft.modid + ":Pistol"), pistol.getUnlocalizedName().substring(5));
	}
	
	public static DamageSource causeSteelPistolBulletDamage(Ammo p_76353_0_, Entity p_76353_1_)
    {
        return (new EntityDamageSourceIndirect("bullet", p_76353_0_, p_76353_1_)).setProjectile();
    }

}
