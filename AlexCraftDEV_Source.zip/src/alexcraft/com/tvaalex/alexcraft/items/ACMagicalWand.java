package com.tvaalex.alexcraft.items;

import com.tvaalex.alexcraft.AlexCraft;

import net.minecraft.item.ItemSword;

public class ACMagicalWand extends ItemSword {
	
	private int magicLevel;

	public ACMagicalWand(String unlo, int magicLevel) {
		super(ToolMaterial.GOLD);
		this.setUnlocalizedName(unlo);
		this.magicLevel = magicLevel;
		this.setTextureName(AlexCraft.modid + ":" + unlo);
		this.setCreativeTab(AlexCraft.tabAlexCraftModToolsAndWeapons);
		// TODO Auto-generated constructor stub
	}
	
	public int getMagicLevel() {
		return this.magicLevel;
	}
	

}
