package com.tvaalex.alexcraft.items.entity.grenades;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;

public class MagicalMissileEntity extends EntityThrowable {


	public MagicalMissileEntity(World world) {
		super(world);
		// TODO Auto-generated constructor stub
	}
	
	public MagicalMissileEntity(World world, EntityLivingBase entity) {
		super(world, entity);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	protected void onImpact(MovingObjectPosition var1) {

		if(!this.worldObj.isRemote) {
			
			this.setDead();
			if(!this.worldObj.isRemote) {
				this.worldObj.createExplosion((Entity) null, this.posX, this.posY, this.posZ, 0.75F, true);
			}
			
		}

	}

}
