package com.tvaalex.alexcraft.items.entity.grenades;

import com.tvaalex.alexcraft.AlexCraft;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class ACGrenade extends Item{
	
	public float explosionPower;
	
	public ACGrenade(float ExplosionPower, String unlocalizedName) {
		explosionPower = ExplosionPower;
		this.setUnlocalizedName(unlocalizedName);
		this.setTextureName(AlexCraft.modid + ":" + unlocalizedName);
		this.setCreativeTab(AlexCraft.tabAlexCraftModToolsAndWeapons);
	}
	
	@Override
	public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer player) {
		
		if(!player.capabilities.isCreativeMode) {
			--itemstack.stackSize;
		}
		
		world.playSoundAtEntity(player, "dig.stone", 1.0F, 1.0F);
		
		if(!world.isRemote) {
			world.spawnEntityInWorld(new ACGrenadeEntity(world, player, explosionPower));
		}
		
		return itemstack;
		
	}

}
