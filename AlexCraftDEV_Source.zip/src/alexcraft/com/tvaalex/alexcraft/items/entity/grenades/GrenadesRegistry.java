package com.tvaalex.alexcraft.items.entity.grenades;

import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.item.Item;

public class GrenadesRegistry {
	
	public static Item nukeCore;
	
	public static void loadGrenades() {
		GameRegistry.registerItem(nukeCore = new ACGrenade(1020.0F, "NukeCore"), nukeCore.getUnlocalizedName().substring(5));
	}
}
