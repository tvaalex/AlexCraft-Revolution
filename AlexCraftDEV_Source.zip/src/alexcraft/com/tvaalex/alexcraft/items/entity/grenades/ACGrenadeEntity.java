package com.tvaalex.alexcraft.items.entity.grenades;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;

public class ACGrenadeEntity extends EntityThrowable {

	public float explosionPower;

	public ACGrenadeEntity(World world) {
		super(world);
		// TODO Auto-generated constructor stub
	}
	
	public ACGrenadeEntity(World world, EntityLivingBase entity, float ExplosionPower) {
		super(world, entity);
		explosionPower = ExplosionPower;
		// TODO Auto-generated constructor stub
	}
	
	@Override
	protected void onImpact(MovingObjectPosition var1) {

		if(!this.worldObj.isRemote) {
			this.setDead();
			if(!this.worldObj.isRemote) {
				this.worldObj.createExplosion((Entity) null, this.posX, this.posY, this.posZ, explosionPower, true);
			}
			
		}

	}

}
