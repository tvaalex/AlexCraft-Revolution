package com.tvaalex.alexcraft.items.armor;

import com.tvaalex.alexcraft.AlexCraft;
import com.tvaalex.alexcraft.items.enchants.EnchantmentRegistry;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

public class ACArmor extends ItemArmor {
	public String textureName;

	public ACArmor(String unlocalizedName, ArmorMaterial material, String textureName, int type) {
	    super(material, 0, type);
	    this.textureName = textureName;
	    this.setUnlocalizedName(unlocalizedName);
	    this.setCreativeTab(AlexCraft.tabAlexCraftModArmors);
	}
	
	@Override
	public String getArmorTexture(ItemStack stack, Entity entity, int slot, String type)
	{
	    return AlexCraft.modid + ":textures/models/armor" + this.textureName + "_" + (this.armorType == 2 ? "2" : "1") + ".png";
	}
	
	@SideOnly(Side.CLIENT)
	public void registerIcons(IIconRegister iconRegister) {
		this.itemIcon = iconRegister.registerIcon(AlexCraft.modid + ":armor/" + this.getUnlocalizedName().substring(5));
	}
	
	@Override
	public void onArmorTick(World world, EntityPlayer player, ItemStack stack) {
		int a = EnchantmentHelper.getEnchantmentLevel(EnchantmentRegistry.nocturnalAbility.effectId, stack);
		if(a > 0) {
			player.addPotionEffect(new PotionEffect(Potion.nightVision.getId(), 50, a - 1));
		}
		
		int b = EnchantmentHelper.getEnchantmentLevel(EnchantmentRegistry.draconicHeal.effectId, stack);
		if(b > 0) {
			player.addPotionEffect(new PotionEffect(Potion.regeneration.getId(), 50, (b - 1) * 4));
		}
		
		int c = EnchantmentHelper.getEnchantmentLevel(EnchantmentRegistry.agility.effectId, stack);
		if(c > 0) {
			player.addPotionEffect(new PotionEffect(Potion.moveSpeed.getId(), 50, c - 1));
		}
		
		int d = EnchantmentHelper.getEnchantmentLevel(EnchantmentRegistry.slimyJump.effectId, stack);
		if(d > 0) {
			player.addPotionEffect(new PotionEffect(Potion.jump.getId(), 50, d - 1));
		}
		
		int e = EnchantmentHelper.getEnchantmentLevel(EnchantmentRegistry.autoEat.effectId, stack);
		if(e > 0) {
			if(player.getFoodStats().needFood() == true) {
				player.inventory.damageArmor(5F);
				player.getFoodStats().setFoodLevel(20);
			}
		}
	}
}