package com.tvaalex.alexcraft.items.tools;

import com.tvaalex.alexcraft.AlexCraft;
import com.tvaalex.alexcraft.items.enchants.EnchantmentRegistry;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.server.S23PacketBlockChange;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.event.world.BlockEvent;

public class ACHammer extends ItemPickaxe {
	private int mineRadius = 1;
	private int mineDepth = 0;
	private boolean infiniteUse = false;
	private Material[] materials = { Material.anvil, Material.glass, Material.ice, Material.iron, Material.packedIce,
			Material.piston, Material.rock };

	public ACHammer(Item.ToolMaterial mat) {
		super(mat);
		this.setCreativeTab(AlexCraft.tabAlexCraftModToolsAndWeapons);
	}

	public ACHammer(String name, Item.ToolMaterial mat) {
		this(name, mat, null, false);
	}

	public ACHammer(String name, Item.ToolMaterial mat, String modName) {
		this(name, mat, modName, false);
	}

	public ACHammer(String name, Item.ToolMaterial mat, String modName, boolean hasInfiniteUse) {
		super(mat);
		this.setUnlocalizedName(name);
		this.setCreativeTab(AlexCraft.tabAlexCraftModToolsAndWeapons);
		this.setTextureName(AlexCraft.modid + ":ToolsNWeapons/" + name);
		this.infiniteUse = hasInfiniteUse;
	}

	public void setInfinite(boolean isInfinite) {
		this.infiniteUse = isInfinite;
	}

	public boolean func_77644_a(ItemStack stack, EntityLivingBase player, EntityLivingBase entity) {
		if (this.infiniteUse) {
			return false;
		}
		return super.hitEntity(stack, player, entity);
	}

	public boolean func_150894_a(ItemStack stack, World world, Block block, int x, int y, int z,
			EntityLivingBase player) {
		if (this.infiniteUse) {
			return false;
		}
		return super.onBlockDestroyed(stack, world, block, x, y, z, player);
	}

	public boolean isEffective(Material material) {
		for (Material m : this.materials) {
			if (m == material) {
				return true;
			}
		}
		return false;
	}

	protected void breakExtraBlock(World world, int x, int y, int z, int sidehit, EntityPlayer playerEntity, int refX,
			int refY, int refZ) {
		if (world.isAirBlock(x, y, z)) {
			return;
		}
		if (!(playerEntity instanceof EntityPlayerMP)) {
			return;
		}
		EntityPlayerMP player = (EntityPlayerMP) playerEntity;

		Block block = world.getBlock(x, y, z);
		int meta = world.getBlockMetadata(x, y, z);
		if (!isEffective(block.getMaterial())) {
			return;
		}
		Block refBlock = world.getBlock(refX, refY, refZ);
		float refStrength = ForgeHooks.blockStrength(refBlock, player, world, refX, refY, refZ);
		float strength = ForgeHooks.blockStrength(block, player, world, x, y, z);
		if ((!ForgeHooks.canHarvestBlock(block, player, meta)) || (refStrength / strength > 10.0F)) {
			return;
		}
		BlockEvent.BreakEvent event = ForgeHooks.onBlockBreakEvent(world, player.theItemInWorldManager.getGameType(),
				player, x, y, z);
		if (event.isCanceled()) {
			return;
		}
		if (player.capabilities.isCreativeMode) {
			block.onBlockHarvested(world, x, y, z, meta, player);
			if (block.removedByPlayer(world, player, x, y, z, false)) {
				block.onBlockDestroyedByPlayer(world, x, y, z, meta);
			}
			if (!world.isRemote) {
				player.playerNetServerHandler.sendPacket(new S23PacketBlockChange(x, y, z, world));
			}
			return;
		}
		player.getCurrentEquippedItem().func_150999_a(world, block, x, y, z, player);
		if (!world.isRemote) {
			block.onBlockHarvested(world, x, y, z, meta, player);
			if (block.removedByPlayer(world, player, x, y, z, true)) {
				block.onBlockDestroyedByPlayer(world, x, y, z, meta);
				block.harvestBlock(world, player, x, y, z, meta);
				block.dropXpOnBlockBreak(world, x, y, z, event.getExpToDrop());
			}
			player.playerNetServerHandler.sendPacket(new S23PacketBlockChange(x, y, z, world));
		} else {
			world.playAuxSFX(2001, x, y, z, Block.getIdFromBlock(block) + (meta << 12));
			if (block.removedByPlayer(world, player, x, y, z, true)) {
				block.onBlockDestroyedByPlayer(world, x, y, z, meta);
			}
			ItemStack itemstack = player.getCurrentEquippedItem();
			if (itemstack != null) {
				itemstack.func_150999_a(world, block, x, y, z, player);
				if (itemstack.stackSize == 0) {
					player.destroyCurrentEquippedItem();
				}
			}
			Minecraft.getMinecraft().getNetHandler().addToSendQueue(
					new C07PacketPlayerDigging(2, x, y, z, Minecraft.getMinecraft().objectMouseOver.sideHit));
		}
	}

	public boolean onBlockStartBreak(ItemStack stack, int x, int y, int z, EntityPlayer player) {
		Block block = player.worldObj.getBlock(x, y, z);
		MovingObjectPosition mop = Common.raytraceFromEntity(player.worldObj, player, false, 4.5D);
		if (mop == null) {
			return super.onBlockStartBreak(stack, x, y, z, player);
		}
		int sideHit = mop.sideHit;
		if (!isEffective(block.getMaterial())) {
			return super.onBlockStartBreak(stack, x, y, z, player);
		}
		int yDist = this.mineRadius;
		int xDist = this.mineRadius;
		int zDist = this.mineRadius;
		switch (sideHit) {
		case 0:
		case 1:
			yDist = this.mineDepth;
			break;
		case 2:
		case 3:
			zDist = this.mineDepth;
			break;
		case 4:
		case 5:
			xDist = this.mineDepth;
		}
		for (int xPos = x - xDist; xPos <= x + xDist; xPos++) {
			for (int yPos = y - yDist; yPos <= y + yDist; yPos++) {
				for (int zPos = z - zDist; zPos <= z + zDist; zPos++) {
					if ((xPos != x) || (yPos != y) || (zPos != z)) {
						if (!super.onBlockStartBreak(stack, xPos, yPos, zPos, player)) {
							breakExtraBlock(player.worldObj, xPos, yPos, zPos, sideHit, player, x, y, z);
						}
					}
				}
			}
		}
		return super.onBlockStartBreak(stack, x, y, z, player);
	}

	@Override
	public void onUpdate(ItemStack stack, World world, Entity entity, int par4, boolean par5) {
		super.onUpdate(stack, world, entity, par4, par5);
		{
			int a = EnchantmentHelper.getEnchantmentLevel(EnchantmentRegistry.rangex.effectId, stack);
			if(a > 0) {
				this.mineRadius = 1 + a;
			}
			
			int b = EnchantmentHelper.getEnchantmentLevel(EnchantmentRegistry.deeper.effectId, stack);
			if(b > 0) {
				this.mineDepth = b;
			}
		}
	}
}