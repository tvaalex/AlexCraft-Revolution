package com.tvaalex.alexcraft.items.tools;

import com.tvaalex.alexcraft.AlexCraft;
import com.tvaalex.alexcraft.items.entity.grenades.SismicWaveEntity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

public class ACGauntlet extends ItemPickaxe {

	public ACGauntlet(ToolMaterial material, String unlocalizedName) {
		super(material);
		this.setUnlocalizedName(unlocalizedName);
		this.setMaxDamage(120);
		this.setTextureName(AlexCraft.modid + ":ToolsNWeapons/" + unlocalizedName);
		this.setCreativeTab(AlexCraft.tabAlexCraftModToolsAndWeapons);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer player) {
		
		world.playSoundAtEntity(player, "dig.glass", 1.0F, 1.0F);
		
		if(!world.isRemote) {
			world.spawnEntityInWorld(new SismicWaveEntity(world, player));
		}
		
		return itemstack;
		
	}
	
	@Override
	public void onUpdate(ItemStack stack, World world, Entity entity, int par4, boolean par5) {
		super.onUpdate(stack, world, entity, par4, par5);
		{
			EntityPlayer player = (EntityPlayer) entity;
			ItemStack equipped = player.getCurrentEquippedItem();
			if(equipped == stack) {
				player.addPotionEffect(new PotionEffect(Potion.moveSpeed.getId(), 100, 4));
				player.addPotionEffect(new PotionEffect(Potion.digSpeed.getId(), 100, 2));
			}
		}
	}

}
