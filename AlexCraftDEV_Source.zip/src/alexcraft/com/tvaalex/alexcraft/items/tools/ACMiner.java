package com.tvaalex.alexcraft.items.tools;

import com.tvaalex.alexcraft.items.enchants.EnchantmentRegistry;
import com.tvaalex.alexcraft.items.entity.grenades.ACGrenadeEntity;
import com.tvaalex.alexcraft.items.entity.grenades.SismicWaveEntity;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

public class ACMiner extends ACHammer {

	
	public ACMiner(String name, ToolMaterial mat) {
		super(name, mat);
		// TODO Auto-generated constructor stub
	}

	public boolean hasEffect(ItemStack par1ItemStack)
	{
		    return false;
	}
	
	@Override
	public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer player) {
		return itemstack;
		
	}
	
	@Override
	public void onUpdate(ItemStack stack, World world, Entity entity, int par4, boolean par5) {

		stack.addEnchantment(EnchantmentRegistry.deeper, 5);
		stack.addEnchantment(EnchantmentRegistry.rangex, 5);
		
		super.onUpdate(stack, world, entity, par4, par5);
		{
			EntityPlayer player = (EntityPlayer) entity;
			ItemStack equipped = player.getCurrentEquippedItem();
			if (equipped == stack) {
				player.addPotionEffect(new PotionEffect(Potion.digSpeed.getId(), 0, 8));
			}
		}
	}

}
