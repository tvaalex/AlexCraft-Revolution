package com.tvaalex.alexcraft.items.tools;

import com.tvaalex.alexcraft.AlexCraft;
import com.tvaalex.alexcraft.OtherThings;
import com.tvaalex.alexcraft.items.food.FoodRegistry;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class ACPortableBBQ extends Item{
	
	public ACPortableBBQ(String unlo) {
		this.setMaxDamage(510);
		this.setUnlocalizedName(unlo);
		this.setTextureName(AlexCraft.modid + ":ToolsNWeapons/" + unlo);
	}

	@Override
	public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer player) {
		while(player.inventory.hasItem(Items.porkchop)) {
			player.inventory.consumeInventoryItem(Items.porkchop);
			player.inventory.addItemStackToInventory(new ItemStack(Items.cooked_porkchop));
			this.setDamage(itemstack, this.getDamage(itemstack) + 1);
		}
		while(player.inventory.hasItem(Items.chicken)) {
			player.inventory.consumeInventoryItem(Items.chicken);
			player.inventory.addItemStackToInventory(new ItemStack(Items.cooked_chicken));
			this.setDamage(itemstack, this.getDamage(itemstack) + 1);
		}
		while(player.inventory.hasItem(Items.beef)) {
			player.inventory.consumeInventoryItem(Items.beef);
			player.inventory.addItemStackToInventory(new ItemStack(Items.cooked_beef));
			this.setDamage(itemstack, this.getDamage(itemstack) + 1);
		}
		while(player.inventory.hasItem(Items.fish)) {
			player.inventory.consumeInventoryItem(Items.fish);
			player.inventory.addItemStackToInventory(new ItemStack(Items.cooked_fished));
			this.setDamage(itemstack, this.getDamage(itemstack) + 1);
		}
		while(player.inventory.hasItem(Items.bread)) {
			player.inventory.consumeInventoryItem(Items.bread);
			player.inventory.addItemStackToInventory(new ItemStack(FoodRegistry.itemToastFood));
			this.setDamage(itemstack, this.getDamage(itemstack) + 1);
		}
		
		return itemstack;
		
	}
	
}
