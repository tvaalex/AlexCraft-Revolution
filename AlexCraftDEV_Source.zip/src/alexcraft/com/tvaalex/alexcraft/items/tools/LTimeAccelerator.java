package com.tvaalex.alexcraft.items.tools;

import java.util.List;

import com.tvaalex.alexcraft.AlexCraft;
import com.tvaalex.alexcraft.items.entity.grenades.ACGrenadeEntity;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

public class LTimeAccelerator extends ItemSword {

	public LTimeAccelerator(String unlocalizedName, ToolMaterial material) {
		super(material);
		this.setCreativeTab(AlexCraft.tabAlexCraftModUtilities);
		this.setUnlocalizedName(unlocalizedName);
		this.setTextureName(AlexCraft.modid + ":/Gadgets/" + unlocalizedName);
		// TODO Auto-generated constructor stub
	}

	public void onUpdate(ItemStack itemstack, World par2World, Entity par3Entity, int par4, boolean par5) {
		if (itemstack.isItemEnchanted() == false) {
			itemstack.addEnchantment(Enchantment.knockback, 10000);
		}
	}
	
	public boolean hasEffect(ItemStack par1ItemStack)
	{
		    return false;
	}
	
	@Override
	public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer player) {
		
		this.setDamage(itemstack, this.getDamage(itemstack) + 1);
		player.addPotionEffect(new PotionEffect(Potion.moveSpeed.getId(), 100, 1800));
		
		return itemstack;
		
	}
	
	public void addInformation(ItemStack par1ItemStack, EntityPlayer playerEntity, List par3List, boolean par4)
	{
	par3List.add("�l�n�6Legendary");
	}


}
