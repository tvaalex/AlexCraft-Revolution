package com.tvaalex.alexcraft.items.tools;

import com.tvaalex.alexcraft.OtherThings;
import com.tvaalex.alexcraft.items.entity.grenades.MagicalMissileEntity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

public class ACETSword extends ACSword {

	public ACETSword(String unlocalizedName, ToolMaterial material) {
		super(unlocalizedName, material);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onUpdate(ItemStack stack, World world, Entity entity, int par4, boolean par5) {
		super.onUpdate(stack, world, entity, par4, par5);
		{
			EntityPlayer player = (EntityPlayer) entity;
			ItemStack equipped = player.getCurrentEquippedItem();
			if (equipped == stack) {
				if (this.getDamage(equipped) <= 21) {
					player.addPotionEffect(new PotionEffect(Potion.moveSpeed.getId(), 1, 2));
					player.addPotionEffect(new PotionEffect(Potion.damageBoost.getId(), 1, 14));
					player.addPotionEffect(new PotionEffect(Potion.resistance.getId(), 1, 5));
					player.addPotionEffect(new PotionEffect(Potion.nightVision.getId(), 1, 1));
					player.addPotionEffect(new PotionEffect(Potion.invisibility.getId(), 100, 1));
				} else {
					player.addPotionEffect(new PotionEffect(Potion.moveSlowdown.getId(), 1, 3));
				}
			}
		}
	}

	@Override
	public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer player) {
		if (player.inventory.hasItem(OtherThings.etPowder)) {
			player.inventory.consumeInventoryItem(OtherThings.etPowder);
			this.setDamage(itemstack, this.getDamage(itemstack) - 3);
		}

		return itemstack;

	}

}
