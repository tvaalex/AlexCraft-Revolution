package com.tvaalex.alexcraft.items.tools;

import java.util.Set;

import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Sets;
import com.tvaalex.alexcraft.AlexCraft;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemStack;

public class ACMultiTool extends ItemPickaxe {
	
	public ACMultiTool(String unlocalizedName, ToolMaterial material) {
        super(material);
        this.setUnlocalizedName(unlocalizedName);
        this.setTextureName(AlexCraft.modid + ":ToolsNWeapons/" + unlocalizedName);
        this.setCreativeTab(AlexCraft.tabAlexCraftModToolsAndWeapons);
    }
	
	@Override
	public Set<String> getToolClasses(ItemStack stack) {
	    return ImmutableSet.of("pickaxe", "spade", "sword", "axe");
	}
	
	private static Set effectiveAgainst = Sets.newHashSet(new Block[] {
		    Blocks.grass, Blocks.dirt, Blocks.sand, Blocks.gravel, 
		    Blocks.snow_layer, Blocks.snow, Blocks.clay, Blocks.farmland, 
		    Blocks.soul_sand, Blocks.mycelium, Blocks.stone, Blocks.planks,
		    Blocks.bookshelf, Blocks.log, Blocks.log2, Blocks.chest,
		    Blocks.pumpkin, Blocks.lit_pumpkin, Blocks.stone});
	
	@Override
	public float func_150893_a(ItemStack stack, Block block) {
	    if (block.getMaterial() == Material.wood || block.getMaterial() == Material.vine || block.getMaterial() == Material.plants)
	        return this.efficiencyOnProperMaterial;
	    return effectiveAgainst.contains(block) ? this.efficiencyOnProperMaterial : super.func_150893_a(stack, block);
	}
	

}
