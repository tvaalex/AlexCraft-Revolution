package com.tvaalex.alexcraft.items.tools;

import com.tvaalex.alexcraft.AlexCraft;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPickaxe;

public class ACPick extends ItemPickaxe {

	public ACPick(String unlocalizedName, ToolMaterial material) {
		super(material);
		if(unlocalizedName == "SploutchPickaxeTier1" || unlocalizedName == "SploutchPickaxeTier2" || unlocalizedName == "SploutchPickaxeTier3" || unlocalizedName == "SploutchPickaxeTier4" || unlocalizedName == "SploutchPickaxeTier5" || unlocalizedName == "SploutchPickaxeTier6" || unlocalizedName == "SploutchPickaxeTier7" || unlocalizedName == "SploutchPickaxeTier8") {
			this.setTextureName(AlexCraft.modid + ":ToolsNWeapons/" + "SploutchPickaxe");
		}else {
		this.setTextureName(AlexCraft.modid + ":ToolsNWeapons/" + unlocalizedName);
		}
		this.setUnlocalizedName(unlocalizedName);
        this.setCreativeTab(AlexCraft.tabAlexCraftModToolsAndWeapons);
	}

}
