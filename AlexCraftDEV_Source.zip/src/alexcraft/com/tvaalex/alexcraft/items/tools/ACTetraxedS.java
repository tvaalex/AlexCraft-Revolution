package com.tvaalex.alexcraft.items.tools;

import com.tvaalex.alexcraft.AlexCraft;
import com.tvaalex.alexcraft.items.entity.grenades.MagicalMissileEntity;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

public class ACTetraxedS extends ItemSword {

	private boolean isKnockbackMode;
	
	public ACTetraxedS(String unlocalizedName, ToolMaterial material) {
		super(material);
		this.setUnlocalizedName(unlocalizedName);
        this.setCreativeTab(AlexCraft.tabAlexCraftModToolsAndWeapons);
        this.setNoRepair();
	}
	
	@SideOnly(Side.CLIENT)
	public void registerIcons(IIconRegister iconRegister) {
		this.itemIcon = iconRegister.registerIcon(AlexCraft.modid + ":ToolsNWeapons/" + this.getUnlocalizedName().substring(5));
	}
	
	
	@Override
	public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer player) {
	
		return itemstack;
		
	}
	
	
	@Override
	public void onUpdate(ItemStack stack, World world, Entity entity, int par4, boolean par5) {
		if (stack.isItemEnchanted() == false) {
			stack.addEnchantment(Enchantment.knockback, 10);
		}
		
		super.onUpdate(stack, world, entity, par4, par5);
		{
			EntityPlayer player = (EntityPlayer) entity;
			ItemStack equipped = player.getCurrentEquippedItem();
			if(equipped == stack) {
				player.addPotionEffect(new PotionEffect(Potion.invisibility.getId(), 0, 1));
				player.addPotionEffect(new PotionEffect(Potion.regeneration.getId(), 0, 100));
				player.addPotionEffect(new PotionEffect(Potion.damageBoost.getId(), 0, 100));
				player.addPotionEffect(new PotionEffect(Potion.resistance.getId(), 0, 10));
				player.addPotionEffect(new PotionEffect(Potion.moveSpeed.getId(), 0, 25));
				player.addPotionEffect(new PotionEffect(Potion.jump.getId(), 0, 8));
			}
		}
	}

}


