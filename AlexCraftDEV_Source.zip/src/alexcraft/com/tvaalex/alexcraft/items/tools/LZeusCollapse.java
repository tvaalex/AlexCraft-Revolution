package com.tvaalex.alexcraft.items.tools;

import java.util.List;
import java.util.Random;

import com.tvaalex.alexcraft.items.entity.grenades.MagicalMissileEntity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ChatComponentText;
import net.minecraft.world.World;

public class LZeusCollapse extends ACSword {

	public LZeusCollapse(String unlocalizedName, ToolMaterial material) {
		super(unlocalizedName, material);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer player) {
		
		this.setDamage(itemstack, this.getDamage(itemstack) + 1);
		
		if(!world.isRemote) {
			player.addChatMessage(new ChatComponentText("�l�b'Till world collapse!")); 
			player.addPotionEffect(new PotionEffect(Potion.resistance.getId(), 4800, 1000));
			player.addPotionEffect(new PotionEffect(Potion.moveSpeed.getId(), 4800, 12));
			player.addPotionEffect(new PotionEffect(Potion.digSpeed.getId(), 4800, 100));
			player.addPotionEffect(new PotionEffect(Potion.damageBoost.getId(), 4800, 5));
			Random rand = new Random(); 
			for(int i = 0; i < rand.nextInt(10)+5; i++) {
				player.worldObj.spawnParticle("enchantmenttable", player.posX, player.posY, player.posZ, 1.0D, 1.0D, 1.0D);
				player.worldObj.spawnParticle("magicCrit", player.posX, player.posY, player.posZ, 1.0D, 1.0D, 1.0D);
			}
		}
		
		return itemstack;
		
	}
	
	public void addInformation(ItemStack par1ItemStack, EntityPlayer playerEntity, List par3List, boolean par4)
	{
	par3List.add("�l�n�6Legendary");
	}

}
