package com.tvaalex.alexcraft.items.tools;

import com.tvaalex.alexcraft.AlexCraft;
import com.tvaalex.alexcraft.items.entity.grenades.MagicalMissileEntity;
import com.tvaalex.alexcraft.items.entity.grenades.SismicWaveEntity;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemSword;
import net.minecraft.item.Item.ToolMaterial;
import net.minecraft.world.World;
import net.minecraft.item.ItemStack;

public class ACSword extends ItemSword {

	public ACSword(String unlocalizedName, ToolMaterial material) {
		super(material);
		if(unlocalizedName == "SploutchSwordTier1" || unlocalizedName == "SploutchSwordTier2" || unlocalizedName == "SploutchSwordTier3" || unlocalizedName == "SploutchSwordTier4" || unlocalizedName == "SploutchSwordTier5" || unlocalizedName == "SploutchSwordTier6" || unlocalizedName == "SploutchSwordTier7" || unlocalizedName == "SploutchSwordTier8") {
			this.setTextureName(AlexCraft.modid + ":ToolsNWeapons/" + "SploutchSword");
		}else {
		this.setTextureName(AlexCraft.modid + ":ToolsNWeapons/" + unlocalizedName);
		}
		this.setUnlocalizedName(unlocalizedName);
        this.setCreativeTab(AlexCraft.tabAlexCraftModToolsAndWeapons);
	}
	

}

