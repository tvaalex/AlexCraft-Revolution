package com.tvaalex.alexcraft.items.food;

import com.tvaalex.alexcraft.AlexCraft;

import net.minecraft.item.ItemFood;

public class ACFood extends ItemFood{

	public ACFood(String unlocalizedName, int healAmount, float saturation, boolean isWolfMeat) {
		super(healAmount, saturation, isWolfMeat);
		this.setUnlocalizedName(unlocalizedName);
		this.setCreativeTab(AlexCraft.tabAlexCraftModFood);
		this.setTextureName(AlexCraft.modid + ":Food/" + unlocalizedName);
		// TODO Auto-generated constructor stub
	}

}
