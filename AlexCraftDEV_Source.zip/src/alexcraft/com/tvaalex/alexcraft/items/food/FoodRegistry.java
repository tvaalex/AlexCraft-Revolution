package com.tvaalex.alexcraft.items.food;

import com.tvaalex.alexcraft.AlexCraft;

import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.item.Item;

public class FoodRegistry {
	
	public static Item itemDoritosFood;
	public static Item itemCantaloupeFood;
	public static Item itemHoneyMelonFood;
	public static Item itemMaxMelonFood;
	public static Item itemToastFood;
	//ADMINFOOD!!!
	public static Item ADMINFOOD;
	
	public static void LoadAll() {
		GameRegistry.registerItem(itemDoritosFood = new ACFood("ItemDoritosFood", 3, 0.8F, true), itemDoritosFood.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(itemToastFood = new ACFood("ItemToastFood", 6, 7.5F, false), itemToastFood.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(itemCantaloupeFood = new ACFood("ItemCantaloupeFood", 4, 0.5F, false), itemCantaloupeFood.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(itemMaxMelonFood = new ACFood("ItemMaxMelonFood", 9, 1.2F, false), itemMaxMelonFood.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(itemHoneyMelonFood = new ACFood("ItemHoneyMelonFood", 4, 0.5F, false), itemHoneyMelonFood.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(ADMINFOOD = new AdminFood("ADMIN_FOOD", 100, 100.0F, true), ADMINFOOD.getUnlocalizedName().substring(5));
	}

}
