package com.tvaalex.alexcraft.items.food;

import com.tvaalex.alexcraft.AlexCraft;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

public class AdminFood extends ItemFood{
	
	public AdminFood(String unlocalizedName, int healAmount, float saturation, boolean isWolfFavorite) {
		super(healAmount, saturation, isWolfFavorite);
		this.setUnlocalizedName(unlocalizedName);
		// TODO Auto-generated constructor stub
	}
	
	@SideOnly(Side.CLIENT)
	public void registerIcons(IIconRegister iconRegister) {
		this.itemIcon = iconRegister.registerIcon(AlexCraft.modid + ":" + this.getUnlocalizedName().substring(5));
	}
	
	@Override
	protected void onFoodEaten(ItemStack itemstack, World world, EntityPlayer player) {
		super.onFoodEaten(itemstack, world, player);
		
		player.setAbsorptionAmount(100.0F);
		player.addPotionEffect(new PotionEffect(Potion.moveSpeed.getId(), 15000, 1000));
		player.addPotionEffect(new PotionEffect(Potion.regeneration.getId(), 15000, 1000));
		player.addPotionEffect(new PotionEffect(Potion.digSpeed.getId(), 15000, 1000));
		player.addPotionEffect(new PotionEffect(Potion.damageBoost.getId(), 15000, 1000));

	}

}
