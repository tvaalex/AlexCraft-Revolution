package com.tvaalex.alexcraft.items;

import com.tvaalex.alexcraft.AlexCraft;

import net.minecraft.item.Item;

public class Tetrax extends Item {
	
	public Tetrax(String unlocalizedName) {
		
		this.setUnlocalizedName(unlocalizedName);
		this.setTextureName(AlexCraft.modid + ":" + unlocalizedName);
		this.setMaxDamage(3);
		this.setNoRepair();
		this.setMaxStackSize(1);
		
	}

}
