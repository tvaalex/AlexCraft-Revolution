package com.tvaalex.alexcraft;

import com.tvaalex.alexcraft.items.tools.LTimeAccelerator;
import com.tvaalex.alexcraft.items.tools.LZeusCollapse;

import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.item.Item;
import net.minecraftforge.common.util.EnumHelper;

public class LegendaryWeaponsRegistry {
	
	public static Item zeusCollapse;
	public static final Item.ToolMaterial zeusCollapseToolMaterial = EnumHelper.addToolMaterial("ZeusCollapseToolMaterial", 0, 50, 0F, 4F, 1000); 
	
	public static Item timeAccelerator;
	public static final Item.ToolMaterial timeAcceleratorToolMaterial = EnumHelper.addToolMaterial("TimeAcceleratorToolMaterial", 0, 50, 0F, 4F, 1000);   
	
	public static void register() {
		GameRegistry.registerItem(zeusCollapse = new LZeusCollapse("ZeusCollapse", zeusCollapseToolMaterial), zeusCollapse.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(timeAccelerator = new LTimeAccelerator("TimeAccelerator", timeAcceleratorToolMaterial), timeAccelerator.getUnlocalizedName().substring(5));
	}

}
