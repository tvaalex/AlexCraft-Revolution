package com.tvaalex.alexcraft.entity;
//Exported java file
//Keep in mind that you still need to fill in some blanks
// - ZeuX

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class BlockEater extends ModelBase
{
	public BlockEater()
	{
		Head = new ModelRenderer(this, 0, 0);
		Head.addBox(-5F, 0F, -5F, 15, 10, 10, 0F);
		Head.setRotationPoint(0F, 0F, 0F);
		Head.rotateAngleX = 0F;
		Head.rotateAngleY = 0F;
		Head.rotateAngleZ = 0F;
		Head.mirror = false;
		Neck = new ModelRenderer(this, 0, 0);
		Neck.addBox(-3F, 0F, -3F, 8, 2, 6, 0F);
		Neck.setRotationPoint(4F, 10F, 0F);
		Neck.rotateAngleX = 0F;
		Neck.rotateAngleY = 0F;
		Neck.rotateAngleZ = 0F;
		Neck.mirror = false;
		Shape2 = new ModelRenderer(this, 0, 0);
		Shape2.addBox(0F, 0F, 0F, 1, 1, 1, 0F);
		Shape2.setRotationPoint(0F, 0F, 0F);
		Shape2.rotateAngleX = 0F;
		Shape2.rotateAngleY = 0F;
		Shape2.rotateAngleZ = 0F;
		Shape2.mirror = false;
		Leg2 = new ModelRenderer(this, 0, 0);
		Leg2.addBox(0F, 0F, 0F, 2, 5, 2, 0F);
		Leg2.setRotationPoint(7F, 12F, 1F);
		Leg2.rotateAngleX = 0F;
		Leg2.rotateAngleY = 0F;
		Leg2.rotateAngleZ = 0F;
		Leg2.mirror = false;
		Leg1 = new ModelRenderer(this, 0, 0);
		Leg1.addBox(0F, -2F, 0F, 2, 5, 2, 0F);
		Leg1.setRotationPoint(7F, 14F, -3F);
		Leg1.rotateAngleX = 0F;
		Leg1.rotateAngleY = 0F;
		Leg1.rotateAngleZ = 0F;
		Leg1.mirror = false;
		Leg3 = new ModelRenderer(this, 0, 0);
		Leg3.addBox(0F, 0F, 0F, 2, 5, 2, 0F);
		Leg3.setRotationPoint(1F, 12F, -3F);
		Leg3.rotateAngleX = 0.01745329F;
		Leg3.rotateAngleY = 0F;
		Leg3.rotateAngleZ = 0F;
		Leg3.mirror = false;
		Leg4 = new ModelRenderer(this, 0, 0);
		Leg4.addBox(0F, 0F, 0F, 2, 5, 2, 0F);
		Leg4.setRotationPoint(1F, 12F, 1F);
		Leg4.rotateAngleX = 0.01745329F;
		Leg4.rotateAngleY = 0F;
		Leg4.rotateAngleZ = 0F;
		Leg4.mirror = false;
	}
	
	public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5)
	{
		super.render(entity, f, f1, f2, f3, f4, f5);
		setRotationAngles(f, f1, f2, f3, f4, f5, entity);
		Head.render(f5);
		Neck.render(f5);
		Shape2.render(f5);
		Leg2.render(f5);
		Leg1.render(f5);
		Leg3.render(f5);
		Leg4.render(f5);
	}
	
	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity entity)
	{
		super.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
	}
	
	//fields
	public ModelRenderer Head;
	public ModelRenderer Neck;
	public ModelRenderer Shape2;
	public ModelRenderer Leg2;
	public ModelRenderer Leg1;
	public ModelRenderer Leg3;
	public ModelRenderer Leg4;
}
