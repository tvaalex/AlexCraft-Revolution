package com.tvaalex.alexcraft.entity;

import com.tvaalex.alexcraft.AlexCraft;
import com.tvaalex.alexcraft.items.entity.grenades.SismicWaveEntity;
import com.tvaalex.alexcraft.items.guns.Ammo;
import com.tvaalex.alexcraft.items.tools.ACArrow;
import com.tvaalex.alexcraft.items.tools.ACDaggerThrowed;

import cpw.mods.fml.common.registry.EntityRegistry;
import net.minecraft.entity.EntityList;

public class ACEntity {
	
	public static void mainRegistry() {
		registerEntity();
	}

	public static void registerEntity() {
		// TODO Auto-generated method stub
		createEntity(SismicWaveEntity.class, "SismicWave", 0x71D2F0, 0xEDEDED);
		createEntity(Ammo.class, "Ammo", 0x363636, 0xB5B5B5);
		createEntity(ACArrow.class, "ACArrow", 0x363636, 0xB5B5B5);
		createEntity(ACDaggerThrowed.class, "Dagger", 0x363636, 0xB5B5B5);
	}
	
	public static void createEntity(Class entityClass, String entityname, int solidColor, int spotColor) {
		int randomid = EntityRegistry.findGlobalUniqueEntityId();
		
		EntityRegistry.registerGlobalEntityID(entityClass, entityname, randomid);
		EntityRegistry.registerModEntity(entityClass, entityname, randomid, AlexCraft.modInstance, 64, 1, true);
		
	}
	
	public static void createEgg(int randomid, int solidColor, int spotColor) {
		EntityList.entityEggs.put(Integer.valueOf(randomid), new EntityList.EntityEggInfo(randomid, solidColor, spotColor));
	}

}
