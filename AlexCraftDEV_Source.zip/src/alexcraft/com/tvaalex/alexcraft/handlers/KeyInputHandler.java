package com.tvaalex.alexcraft.handlers;

import com.tvaalex.alexcraft.MagicalRegistry;
import com.tvaalex.alexcraft.items.ACMagicalWand;
import com.tvaalex.alexcraft.keybinding.KeyBindings;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.InputEvent;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;

public class KeyInputHandler {

	@SubscribeEvent
	public void onKeyInput(InputEvent.KeyInputEvent event) {


		if (KeyBindings.water.isPressed()) {
			System.out.println("WATER");
		}

		if (KeyBindings.fire.isPressed()) {
			System.out.println("FIRE");
		}

		if (KeyBindings.lightning.isPressed()) {
			System.out.println("LIGHTNING");
		}

		if (KeyBindings.earth.isPressed()) {
			System.out.println("EARTH");
		}

		if (KeyBindings.light.isPressed()) {
			System.out.println("LIGHT");
		}

		if (KeyBindings.darkness.isPressed()) {
			System.out.println("DARKNESS");
		}

	}
}
