package com.tvaalex.alexcraft;

import com.tvaalex.alexcraft.items.ACMagicalWand;

import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.item.Item;

public class MagicalRegistry {
	
	public static Item magicalWand;
	
	public static void LoadAll() {
		GameRegistry.registerItem(magicalWand = new ACMagicalWand("MagicalWand", 1), magicalWand.getUnlocalizedName().substring(5));
	}

}
