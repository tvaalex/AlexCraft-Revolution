package com.tvaalex.alexcraft;

import com.tvaalex.alexcraft.blocks.ACDuplicator;
import com.tvaalex.alexcraft.blocks.ACOreTrader;
import com.tvaalex.alexcraft.blocks.ACRainbowOre;
import com.tvaalex.alexcraft.blocks.ACXRayBlock;
import com.tvaalex.alexcraft.blocks.ACZacCrate;
import com.tvaalex.alexcraft.blocks.UpgradeBlock;
import com.tvaalex.alexcraft.blocks.multiblocks.ACModularStorageMultiBlock;
import com.tvaalex.alexcraft.items.ACItem;
import com.tvaalex.alexcraft.items.armor.ACArmor;
import com.tvaalex.alexcraft.items.electronical.ElectronicalRegistry;
import com.tvaalex.alexcraft.items.tools.ACDagger;
import com.tvaalex.alexcraft.items.tools.ACETSword;
import com.tvaalex.alexcraft.items.tools.ACGauntlet;
import com.tvaalex.alexcraft.items.tools.ACMagicalSword;
import com.tvaalex.alexcraft.items.tools.ACMiner;
import com.tvaalex.alexcraft.items.tools.ACPortableBBQ;
import com.tvaalex.alexcraft.items.tools.ACSword;

import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor.ArmorMaterial;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.util.EnumHelper;

public class OtherThings {
	
	//Other Declaration
	public static Block blockXRayBlock;
	public static Block multiBlockModularStorage;
	public static Block blockRainbowOre;
	public static Block blockZacCrate;
	public static Block oreTrader;
	public static Item elficSword;
	public static Item portableBBQ;
	public static Item magicalSword;
	public static Item sismicGauntlet;
	public static Item multikolory;
	public static Item etSword;
	public static Item theMiner;
	public static Item etPowder;

	//Duplication
	public static Block duplicatorBlock;
	public static Item goldCoins;
	public static Item money;
	public static Block duplicationUpgrade;
	public static Block costUpgrade;
	public static Block ingotUpgrade;
	public static Block blockUpgrade;
	public static Block unstackableUpgrade;
	
	public static final ArmorMaterial ninjaSuitArmorMaterial = EnumHelper.addArmorMaterial("NinjaSuitArmorMaterial", 4, new int[]{3, 3, 3, 3}, 10);
	public static Item ninjaHood;
	public static Item ninjaSuit;
	public static Item ninjaPants;
	public static Item ninjaShoes;
	
	public static final Item.ToolMaterial elficToolMaterial = EnumHelper.addToolMaterial("ElficToolMaterial", 2, 390, 5.0F, 3.5F, 52); 
	public static final Item.ToolMaterial elekiumToolMaterial = EnumHelper.addToolMaterial("ElekiumToolMaterial", 3, 390, 10.0F, 2.0F, 40); 
	public static final Item.ToolMaterial multikoloryToolMaterial = EnumHelper.addToolMaterial("MultikoloryToolMaterial", 3, 1257, 10.0F, 3.476F, 10000); 
	public static final Item.ToolMaterial etToolMaterial = EnumHelper.addToolMaterial("ETToolMaterial", 3, 38, 10.0F, 4F, 10000); 
	public static final Item.ToolMaterial minerToolMaterial = EnumHelper.addToolMaterial("MinerToolMaterial", 5, 54, 100000.0F, 0.0F, 10); 
	
	public static void LoadAll() {
		//Duplication
		GameRegistry.registerBlock(duplicatorBlock = new ACDuplicator().setCreativeTab(AlexCraft.tabAlexCraftModUtilities), duplicatorBlock.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(goldCoins = new ACItem().setUnlocalizedName("GoldCoins").setCreativeTab(AlexCraft.tabAlexCraftModUtilities), goldCoins.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(money = new ACItem().setUnlocalizedName("Money").setCreativeTab(AlexCraft.tabAlexCraftModUtilities), money.getUnlocalizedName().substring(5));
		GameRegistry.registerBlock(duplicationUpgrade = new UpgradeBlock("DuplicationUpgrade"), duplicationUpgrade.getUnlocalizedName().substring(5));
		GameRegistry.registerBlock(costUpgrade = new UpgradeBlock("CostUpgrade"), costUpgrade.getUnlocalizedName().substring(5));
		GameRegistry.registerBlock(ingotUpgrade = new UpgradeBlock("IngotUpgrade"), ingotUpgrade.getUnlocalizedName().substring(5));
		GameRegistry.registerBlock(blockUpgrade = new UpgradeBlock("BlockUpgrade"), blockUpgrade.getUnlocalizedName().substring(5));
		GameRegistry.registerBlock(unstackableUpgrade = new UpgradeBlock("UnstackableUpgrade"), unstackableUpgrade.getUnlocalizedName().substring(5));
		GameRegistry.registerBlock(oreTrader = new ACOreTrader("OreTrader"), oreTrader.getUnlocalizedName().substring(5));
		//OtherThings
		GameRegistry.registerBlock(blockXRayBlock = new ACXRayBlock(Material.glass, "BlockXRayBlock").setCreativeTab(AlexCraft.tabAlexCraftModUtilities), blockXRayBlock.getUnlocalizedName().substring(5));
		GameRegistry.registerBlock(multiBlockModularStorage = new ACModularStorageMultiBlock("MultiBlockModularStorage").setCreativeTab(AlexCraft.tabAlexCraftModUtilities), multiBlockModularStorage.getUnlocalizedName().substring(5));
		GameRegistry.registerBlock(blockRainbowOre = new ACRainbowOre(Material.rock, "BlockRainbowOre"), blockRainbowOre.getUnlocalizedName().substring(5));
		GameRegistry.registerBlock(blockZacCrate = new ACZacCrate(Material.portal, "BlockZacCrate"), blockZacCrate.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(etPowder = new ACItem().setUnlocalizedName("ETPowder").setCreativeTab(AlexCraft.tabAlexCraftModOres), etPowder.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(portableBBQ = new ACPortableBBQ("PortableBBQ").setCreativeTab(AlexCraft.tabAlexCraftModUtilities), portableBBQ.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(elficSword = new ACSword("ElficSword", elficToolMaterial), elficSword.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(multikolory = new ACDagger("Multikolory", 2.678F, multikoloryToolMaterial), multikolory.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(etSword = new ACETSword("ETSword", multikoloryToolMaterial), etSword.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(theMiner = new ACMiner("TheMiner", minerToolMaterial), theMiner.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(magicalSword = new ACMagicalSword("MagicalSword", elficToolMaterial), magicalSword.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(sismicGauntlet = new ACGauntlet(elekiumToolMaterial, "SismicGauntlet"), sismicGauntlet.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(ninjaHood = new ACArmor("NinjaHood", ninjaSuitArmorMaterial, "NinjaSuit", 0), ninjaHood.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(ninjaSuit = new ACArmor("NinjaSuit", ninjaSuitArmorMaterial, "NinjaSuit", 1), ninjaSuit.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(ninjaPants = new ACArmor("NinjaPants", ninjaSuitArmorMaterial, "NinjaSuit", 2), ninjaPants.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(ninjaShoes = new ACArmor("NinjaShoes", ninjaSuitArmorMaterial, "NinjaSuit", 3), ninjaShoes.getUnlocalizedName().substring(5));
		GameRegistry.addRecipe(new ItemStack(multiBlockModularStorage), new Object[] {"XZX", "ZYZ", "XZX", 'X', SteelThings.blockSteelBlock, 'Z', ElekiumThings.itemBasicElekiumCircut, 'Y', ElectronicalRegistry.computerCardStorage});
		GameRegistry.addRecipe(new ItemStack(goldCoins), new Object[] {"XXX", "XXX", "XXX", 'X', money});

	}

}
