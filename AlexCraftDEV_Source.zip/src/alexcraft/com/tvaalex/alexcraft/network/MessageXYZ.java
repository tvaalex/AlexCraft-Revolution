package com.tvaalex.alexcraft.network;

import io.netty.buffer.ByteBuf;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

import com.sun.corba.se.impl.protocol.giopmsgheaders.MessageBase;

import cpw.mods.fml.common.network.simpleimpl.IMessage;

public abstract class MessageXYZ<REQ extends IMessage> extends MessageBase{

    protected static int x;
	protected static int y;
	protected static int z;

    public MessageXYZ(){}

    public MessageXYZ(int x, int y, int z){
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public MessageXYZ(TileEntity te){
        this(te.xCoord, te.yCoord, te.zCoord);
    }

    public void fromBytes(ByteBuf buf){
        x = buf.readInt();
        y = buf.readInt();
        z = buf.readInt();
    }

    public void toBytes(ByteBuf buf){
        buf.writeInt(x);
        buf.writeInt(y);
        buf.writeInt(z);
    }

    protected TileEntity getTileEntity(World world){
        return world.getTileEntity(x, y, z);
    }
}
