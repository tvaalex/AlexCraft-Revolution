package com.tvaalex.alexcraft;

import com.tvaalex.alexcraft.blocks.ACBlock;
import com.tvaalex.alexcraft.items.ACIngot;
import com.tvaalex.alexcraft.items.ACItem;
import com.tvaalex.alexcraft.items.armor.ACArmor;
import com.tvaalex.alexcraft.items.tools.ACAxe;
import com.tvaalex.alexcraft.items.tools.ACHammer;
import com.tvaalex.alexcraft.items.tools.ACHoe;
import com.tvaalex.alexcraft.items.tools.ACMultiTool;
import com.tvaalex.alexcraft.items.tools.ACPick;
import com.tvaalex.alexcraft.items.tools.ACShovel;
import com.tvaalex.alexcraft.items.tools.ACSword;

import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemArmor.ArmorMaterial;
import net.minecraftforge.common.util.EnumHelper;

public class EnderiumThings {
		//Enderium Declarations
		//Items and Blocks
		public static Item itemEnderiumIngot;
		public static Item itemEnderiumHeavyIngot;
		public static Item itemEnderiumStick;
		public static Block blockEnderiumBlock;
		public static Block blockEnderiumOre;
		//Materials
		public static final Item.ToolMaterial enderiumToolMaterial = EnumHelper.addToolMaterial("EnderiumToolMaterial", 4, 1350, 6.0F, 4.5F, 100);   
		public static final ArmorMaterial enderiumArmorMaterial = EnumHelper.addArmorMaterial("EnderiumArmorMaterial", 9, new int[]{6, 7, 5, 4}, 30);
		//Tools
		public static Item enderiumPickaxe;
		public static Item enderiumSword;
		public static Item enderiumAxe;
		public static Item enderiumShovel;
		public static Item enderiumHoe;
		public static Item enderiumMultiTool;
		public static Item enderiumHammer;
		//Armors
		public static Item enderiumHelmet;
		public static Item enderiumChestplate;
		public static Item enderiumLeggings;
		public static Item enderiumBoots;
		
		public static void LoadAll() {
			//Enderium Items and Block Init.
				//Enderium Registry
				GameRegistry.registerItem(itemEnderiumIngot = new ACIngot().setUnlocalizedName("ItemEnderiumIngot"), itemEnderiumIngot.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(itemEnderiumHeavyIngot = new ACIngot().setUnlocalizedName("ItemEnderiumHeavyIngot"), itemEnderiumHeavyIngot.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(itemEnderiumStick = new ACItem().setUnlocalizedName("ItemEnderiumStick"), itemEnderiumStick.getUnlocalizedName().substring(5));
				GameRegistry.registerBlock(blockEnderiumBlock = new ACBlock(Material.iron, 2, 10.0F, 1000.0F).setBlockName("BlockEnderiumBlock").setBlockTextureName(AlexCraft.modid + ":BlockEnderiumBlock"), blockEnderiumBlock.getUnlocalizedName().substring(5));
				GameRegistry.registerBlock(blockEnderiumOre = new ACBlock(Material.rock, 3, 25.0F, 1500.0F).setBlockName("BlockEnderiumOre").setBlockTextureName(AlexCraft.modid + ":BlockEnderiumOre"), blockEnderiumOre.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(enderiumPickaxe = new ACPick("EnderiumPickaxe", enderiumToolMaterial), enderiumPickaxe.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(enderiumSword = new ACSword("EnderiumSword", enderiumToolMaterial), enderiumSword.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(enderiumAxe = new ACAxe("EnderiumAxe", enderiumToolMaterial), enderiumAxe.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(enderiumShovel = new ACShovel("EnderiumShovel", enderiumToolMaterial), enderiumShovel.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(enderiumHoe = new ACHoe("EnderiumHoe", enderiumToolMaterial), enderiumHoe.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(enderiumMultiTool = new ACMultiTool("EnderiumMultiTool", enderiumToolMaterial), enderiumMultiTool.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(enderiumHammer = new ACHammer("EnderiumHammer", enderiumToolMaterial), enderiumHammer.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(enderiumHelmet = new ACArmor("EnderiumHelmet", enderiumArmorMaterial, "EnderiumArmor", 0), enderiumHelmet.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(enderiumChestplate = new ACArmor("EnderiumChestplate", enderiumArmorMaterial, "EnderiumArmor", 1), enderiumChestplate.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(enderiumLeggings = new ACArmor("EnderiumLeggings", enderiumArmorMaterial, "EnderiumArmor", 2), enderiumLeggings.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(enderiumBoots = new ACArmor("EnderiumBoots", enderiumArmorMaterial, "EnderiumArmor", 3), enderiumBoots.getUnlocalizedName().substring(5));				
				//Enderium Crafting Recipies
				//Blocks and Items
				GameRegistry.addRecipe(new ItemStack(itemEnderiumStick), new Object[] {"   ", "X#X", "   ", 'X', itemEnderiumIngot, '#', Items.stick});
				GameRegistry.addRecipe(new ItemStack(enderiumPickaxe), new Object[] {"XXX", " # ", " # ", 'X', itemEnderiumIngot, '#', itemEnderiumStick});
				GameRegistry.addRecipe(new ItemStack(enderiumAxe), new Object[] {"XX ", "X# ", " # ", 'X', itemEnderiumIngot, '#', itemEnderiumStick});
				GameRegistry.addRecipe(new ItemStack(enderiumSword), new Object[] {" X ", " X ", " # ", 'X', itemEnderiumIngot, '#', itemEnderiumStick});
				GameRegistry.addRecipe(new ItemStack(enderiumShovel), new Object[] {" X ", " # ", " # ", 'X', itemEnderiumIngot, '#', itemEnderiumStick});
				GameRegistry.addRecipe(new ItemStack(enderiumHoe), new Object[] {" XX", " # ", " # ", 'X', itemEnderiumIngot, '#', itemEnderiumStick});
				GameRegistry.addRecipe(new ItemStack(enderiumMultiTool), new Object[] {"ZXZ", " # ", " # ", 'X', itemEnderiumIngot, '#', itemEnderiumStick, 'Z', blockEnderiumBlock});
				GameRegistry.addRecipe(new ItemStack(blockEnderiumBlock), new Object[] {"XXX", "XXX", "XXX", 'X', itemEnderiumIngot});
				GameRegistry.addShapelessRecipe(new ItemStack(itemEnderiumIngot, 9), new Object[] {blockEnderiumBlock});
				GameRegistry.addRecipe(new ItemStack(itemEnderiumHeavyIngot), new Object[] {"   ", " XX", " XX", 'X', itemEnderiumIngot});
				GameRegistry.addShapelessRecipe(new ItemStack(itemEnderiumIngot, 4), new Object[] {itemEnderiumHeavyIngot});
				GameRegistry.addRecipe(new ItemStack(enderiumHelmet), new Object[] {"XXX", "X X", "   ", 'X', itemEnderiumIngot});
				GameRegistry.addRecipe(new ItemStack(enderiumChestplate), new Object[] {"X X", "XXX", "XXX", 'X', itemEnderiumIngot});
				GameRegistry.addRecipe(new ItemStack(enderiumLeggings), new Object[] {"XXX", "X X", "X X", 'X', itemEnderiumIngot});
				GameRegistry.addRecipe(new ItemStack(enderiumBoots), new Object[] {"   ", "X X", "X X", 'X', itemEnderiumIngot});
				//Enderium Smelting Recipies
				GameRegistry.addSmelting(blockEnderiumOre, new ItemStack(itemEnderiumIngot), 0.5F);

					
		}

}
