package com.tvaalex.alexcraft;

import com.tvaalex.alexcraft.blocks.ACBlock;
import com.tvaalex.alexcraft.items.ACIngot;
import com.tvaalex.alexcraft.items.ACItem;
import com.tvaalex.alexcraft.items.armor.ACArmor;
import com.tvaalex.alexcraft.items.tools.ACAxe;
import com.tvaalex.alexcraft.items.tools.ACHammer;
import com.tvaalex.alexcraft.items.tools.ACHoe;
import com.tvaalex.alexcraft.items.tools.ACMultiTool;
import com.tvaalex.alexcraft.items.tools.ACPick;
import com.tvaalex.alexcraft.items.tools.ACShovel;
import com.tvaalex.alexcraft.items.tools.ACSword;

import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemArmor.ArmorMaterial;
import net.minecraftforge.common.util.EnumHelper;

public class PalamaxThings {
		//Palamax Declarations
		//Items and Blocks
		public static Item itemPalamaxCrystal;
		public static Item itemPalamaxIngot;
		public static Item itemPalamaxStick;
		public static Block blockPalamaxBlock;
		public static Block blockPalamaxOre;
		//Materials
		public static final Item.ToolMaterial PalamaxToolMaterial = EnumHelper.addToolMaterial("PalamaxToolMaterial", 4, 2000, 8.0F, 4.7F, 30);   
		public static final ArmorMaterial PalamaxArmorMaterial = EnumHelper.addArmorMaterial("PalamaxArmorMaterial", 10, new int[]{4, 6, 5, 3}, 850);
		public static final ArmorMaterial PalamaxHeavyArmorMaterial = EnumHelper.addArmorMaterial("PalamaxHeavyArmorMaterial", 12, new int[]{5, 7, 6, 3}, 1000);
		//Tools
		public static Item PalamaxPickaxe;
		public static Item PalamaxSword;
		public static Item PalamaxAxe;
		public static Item PalamaxShovel;
		public static Item PalamaxHoe;
		public static Item PalamaxMultiTool;
		public static Item palamaxHammer;
		//Armors
		public static Item PalamaxHelmet;
		public static Item PalamaxChestplate;
		public static Item PalamaxLeggings;
		public static Item PalamaxBoots;
		//Heavy Armors
		public static Item PalamaxHeavyHelmet;
		public static Item PalamaxHeavyChestplate;
		public static Item PalamaxHeavyLeggings;
		public static Item PalamaxHeavyBoots;
		
		public static void LoadAll() {
			//Palamax Items and Block Init.
				//Palamax Registry
				GameRegistry.registerItem(itemPalamaxCrystal = new ACIngot().setUnlocalizedName("ItemPalamaxCrystal"), itemPalamaxCrystal.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(itemPalamaxIngot = new ACIngot().setUnlocalizedName("ItemPalamaxIngot"), itemPalamaxIngot.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(itemPalamaxStick = new ACItem().setUnlocalizedName("ItemPalamaxStick"), itemPalamaxStick.getUnlocalizedName().substring(5));
				GameRegistry.registerBlock(blockPalamaxBlock = new ACBlock(Material.iron, 2, 10.0F, 20.0F).setBlockName("BlockPalamaxBlock").setBlockTextureName(AlexCraft.modid + ":BlockPalamaxBlock"), blockPalamaxBlock.getUnlocalizedName().substring(5));
				GameRegistry.registerBlock(blockPalamaxOre = new ACBlock(Material.rock, 3, 17.5F, 34.0F).setBlockName("BlockPalamaxOre").setBlockTextureName(AlexCraft.modid + ":BlockPalamaxOre"), blockPalamaxOre.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(PalamaxPickaxe = new ACPick("PalamaxPickaxe", PalamaxToolMaterial), PalamaxPickaxe.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(PalamaxSword = new ACSword("PalamaxSword", PalamaxToolMaterial), PalamaxSword.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(PalamaxAxe = new ACAxe("PalamaxAxe", PalamaxToolMaterial), PalamaxAxe.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(PalamaxShovel = new ACShovel("PalamaxShovel", PalamaxToolMaterial), PalamaxShovel.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(PalamaxHoe = new ACHoe("PalamaxHoe", PalamaxToolMaterial), PalamaxHoe.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(PalamaxMultiTool = new ACMultiTool("PalamaxMultiTool", PalamaxToolMaterial), PalamaxMultiTool.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(palamaxHammer = new ACHammer("PalamaxHammer", PalamaxToolMaterial), palamaxHammer.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(PalamaxHelmet = new ACArmor("PalamaxHelmet", PalamaxArmorMaterial, "PalamaxArmor", 0), PalamaxHelmet.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(PalamaxChestplate = new ACArmor("PalamaxChestplate", PalamaxArmorMaterial, "PalamaxArmor", 1), PalamaxChestplate.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(PalamaxLeggings = new ACArmor("PalamaxLeggings", PalamaxArmorMaterial, "PalamaxArmor", 2), PalamaxLeggings.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(PalamaxBoots = new ACArmor("PalamaxBoots", PalamaxArmorMaterial, "PalamaxArmor", 3), PalamaxBoots.getUnlocalizedName().substring(5));				
				GameRegistry.registerItem(PalamaxHeavyHelmet = new ACArmor("PalamaxHeavyHelmet", PalamaxHeavyArmorMaterial, "PalamaxHeavyArmor", 0), PalamaxHeavyHelmet.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(PalamaxHeavyChestplate = new ACArmor("PalamaxHeavyChestplate", PalamaxHeavyArmorMaterial, "PalamaxHeavyArmor", 1), PalamaxHeavyChestplate.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(PalamaxHeavyLeggings = new ACArmor("PalamaxHeavyLeggings", PalamaxHeavyArmorMaterial, "PalamaxHeavyArmor", 2), PalamaxHeavyLeggings.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(PalamaxHeavyBoots = new ACArmor("PalamaxHeavyBoots", PalamaxHeavyArmorMaterial, "PalamaxHeavyArmor", 3), PalamaxHeavyBoots.getUnlocalizedName().substring(5));
				//Palamax Crafting Recipies
				//Blocks and Items
				GameRegistry.addRecipe(new ItemStack(itemPalamaxStick), new Object[] {"   ", "X#X", "   ", 'X', itemPalamaxCrystal, '#', Items.stick});
				GameRegistry.addRecipe(new ItemStack(PalamaxPickaxe), new Object[] {"XXX", " # ", " # ", 'X', itemPalamaxCrystal, '#', itemPalamaxStick});
				GameRegistry.addRecipe(new ItemStack(PalamaxAxe), new Object[] {"XX ", "X# ", " # ", 'X', itemPalamaxCrystal, '#', itemPalamaxStick});
				GameRegistry.addRecipe(new ItemStack(PalamaxSword), new Object[] {" X ", " X ", " # ", 'X', itemPalamaxCrystal, '#', itemPalamaxStick});
				GameRegistry.addRecipe(new ItemStack(PalamaxShovel), new Object[] {" X ", " # ", " # ", 'X', itemPalamaxCrystal, '#', itemPalamaxStick});
				GameRegistry.addRecipe(new ItemStack(PalamaxHoe), new Object[] {" XX", " # ", " # ", 'X', itemPalamaxCrystal, '#', itemPalamaxStick});
				GameRegistry.addRecipe(new ItemStack(PalamaxMultiTool), new Object[] {"ZXZ", " # ", " # ", 'X', itemPalamaxCrystal, '#', itemPalamaxStick, 'Z', blockPalamaxBlock});
				GameRegistry.addRecipe(new ItemStack(blockPalamaxBlock), new Object[] {"XXX", "XXX", "XXX", 'X', itemPalamaxCrystal});
				GameRegistry.addShapelessRecipe(new ItemStack(itemPalamaxCrystal, 9), new Object[] {blockPalamaxBlock});
				GameRegistry.addRecipe(new ItemStack(itemPalamaxIngot), new Object[] {"   ", " XX", " XX", 'X', itemPalamaxCrystal});
				GameRegistry.addShapelessRecipe(new ItemStack(itemPalamaxCrystal, 4), new Object[] {itemPalamaxIngot});
				GameRegistry.addRecipe(new ItemStack(PalamaxHelmet), new Object[] {"XXX", "X X", "   ", 'X', itemPalamaxCrystal});
				GameRegistry.addRecipe(new ItemStack(PalamaxChestplate), new Object[] {"X X", "XXX", "XXX", 'X', itemPalamaxCrystal});
				GameRegistry.addRecipe(new ItemStack(PalamaxLeggings), new Object[] {"XXX", "X X", "X X", 'X', itemPalamaxCrystal});
				GameRegistry.addRecipe(new ItemStack(PalamaxBoots), new Object[] {"   ", "X X", "X X", 'X', itemPalamaxCrystal});
				GameRegistry.addRecipe(new ItemStack(PalamaxHeavyHelmet), new Object[] {"XZX", "X X", "   ", 'X', itemPalamaxCrystal,'Z', blockPalamaxBlock});
				GameRegistry.addRecipe(new ItemStack(PalamaxHeavyChestplate), new Object[] {"X X", "XZX", "XXX", 'X', itemPalamaxCrystal, 'Z', blockPalamaxBlock});
				GameRegistry.addRecipe(new ItemStack(PalamaxHeavyLeggings), new Object[] {"XZX", "X X", "X X", 'X', itemPalamaxCrystal, 'Z', blockPalamaxBlock});
				GameRegistry.addRecipe(new ItemStack(PalamaxHeavyBoots), new Object[] {"X X", "X X", "X X", 'X', itemPalamaxCrystal});
				//Palamax Smelting Recipies
				GameRegistry.addSmelting(blockPalamaxOre, new ItemStack(itemPalamaxCrystal), 0.5F);

					
		}

}
