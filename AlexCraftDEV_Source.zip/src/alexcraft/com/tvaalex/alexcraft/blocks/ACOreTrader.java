package com.tvaalex.alexcraft.blocks;

import com.tvaalex.alexcraft.AlexCraft;
import com.tvaalex.alexcraft.AlexiumThings;
import com.tvaalex.alexcraft.CobaltThings;
import com.tvaalex.alexcraft.DarkSteelThings;
import com.tvaalex.alexcraft.EnderiumThings;
import com.tvaalex.alexcraft.OtherThings;
import com.tvaalex.alexcraft.PalamaxThings;
import com.tvaalex.alexcraft.SteelThings;
import com.tvaalex.alexcraft.SuperiumThings;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class ACOreTrader extends Block {
	
	public final int STEEL_VALUE = 4;
	public final int COBALT_VALUE = 4;
	public final int SUPERIUM_VALUE = 8;
	public final int PALAMAX_VALUE = 16;
	public final int ALEXIUM_VALUE = 32;
	public final int ENDERIUM_VALUE = 32;
	public final int ELEKIUM_VALUE = 8;
	public final int DARKSTEEL_VALUE = 16;
	public final int MINECRAFTIUM_VALUE = 64;

	public ACOreTrader(String unlo) {
		super(Material.iron);
		this.setBlockName(unlo);
		this.setBlockTextureName(AlexCraft.modid + ":" + unlo);
		this.setCreativeTab(AlexCraft.tabAlexCraftModUtilities);
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int side, float hitX,
			float hitY, float hitZ) {
		ItemStack current = player.inventory.getCurrentItem();
		if (!player.isSneaking()) {
			if (current.getItem() == SteelThings.itemSteelIngot) {
				player.inventory.consumeInventoryItem(SteelThings.itemSteelIngot);
				player.inventory.addItemStackToInventory(new ItemStack(OtherThings.money, STEEL_VALUE));
			}
			if (current.getItem() == CobaltThings.itemCobaltIngot) {
				player.inventory.consumeInventoryItem(CobaltThings.itemCobaltIngot);
				player.inventory.addItemStackToInventory(new ItemStack(OtherThings.money, COBALT_VALUE));
			}
			if (current.getItem() == SuperiumThings.itemSuperiumIngot) {
				player.inventory.consumeInventoryItem(SuperiumThings.itemSuperiumIngot);
				player.inventory.addItemStackToInventory(new ItemStack(OtherThings.money, SUPERIUM_VALUE));
			}
			if (current.getItem() == PalamaxThings.itemPalamaxIngot) {
				player.inventory.consumeInventoryItem(PalamaxThings.itemPalamaxIngot);
				player.inventory.addItemStackToInventory(new ItemStack(OtherThings.money, PALAMAX_VALUE));
			}
			if (current.getItem() == AlexiumThings.itemAlexiumIngot) {
				player.inventory.consumeInventoryItem(AlexiumThings.itemAlexiumIngot);
				player.inventory.addItemStackToInventory(new ItemStack(OtherThings.money, ALEXIUM_VALUE));
			}
			if (current.getItem() == EnderiumThings.itemEnderiumIngot) {
				player.inventory.consumeInventoryItem(EnderiumThings.itemEnderiumIngot);
				player.inventory.addItemStackToInventory(new ItemStack(OtherThings.money, ENDERIUM_VALUE));
			}
			if (current.getItem() == DarkSteelThings.itemDarkSteelIngot) {
				player.inventory.consumeInventoryItem(DarkSteelThings.itemDarkSteelIngot);
				player.inventory.addItemStackToInventory(new ItemStack(OtherThings.money, DARKSTEEL_VALUE));
			}
		}else {
			if (current.getItem() == SteelThings.itemSteelIngot) {
				for(int i = 0;i < current.stackSize; i++) {
					player.inventory.consumeInventoryItem(SteelThings.itemSteelIngot);
				}
				player.inventory.addItemStackToInventory(new ItemStack(OtherThings.money, (STEEL_VALUE * current.stackSize)));
			}
			if (current.getItem() == CobaltThings.itemCobaltIngot) {
				for(int i = 0;i < current.stackSize; i++) {
					player.inventory.consumeInventoryItem(CobaltThings.itemCobaltIngot);
				}
				player.inventory.addItemStackToInventory(new ItemStack(OtherThings.money, (COBALT_VALUE * current.stackSize)));
			}
			if (current.getItem() == SuperiumThings.itemSuperiumIngot) {
				for(int i = 0;i < current.stackSize; i++) {
					player.inventory.consumeInventoryItem(SuperiumThings.itemSuperiumIngot);
				}
				player.inventory.addItemStackToInventory(new ItemStack(OtherThings.money, (SUPERIUM_VALUE * current.stackSize)));
			}
			if (current.getItem() == PalamaxThings.itemPalamaxIngot) {
				for(int i = 0;i < current.stackSize; i++) {
					player.inventory.consumeInventoryItem(PalamaxThings.itemPalamaxIngot);
				}
				player.inventory.addItemStackToInventory(new ItemStack(OtherThings.money, (PALAMAX_VALUE * current.stackSize)));
			}
			if (current.getItem() == AlexiumThings.itemAlexiumIngot) {
				for(int i = 0;i < current.stackSize; i++) {
					player.inventory.consumeInventoryItem(AlexiumThings.itemAlexiumIngot);
				}
				player.inventory.addItemStackToInventory(new ItemStack(OtherThings.money, (ALEXIUM_VALUE * current.stackSize)));
			}
			if (current.getItem() == EnderiumThings.itemEnderiumIngot) {
				for(int i = 0;i < current.stackSize; i++) {
					player.inventory.consumeInventoryItem(EnderiumThings.itemEnderiumIngot);
				}
				player.inventory.addItemStackToInventory(new ItemStack(OtherThings.money, (ENDERIUM_VALUE * current.stackSize)));
			}
			if (current.getItem() == DarkSteelThings.itemDarkSteelIngot) {
				for(int i = 0;i < current.stackSize; i++) {
					player.inventory.consumeInventoryItem(DarkSteelThings.itemDarkSteelIngot);
				}
				player.inventory.addItemStackToInventory(new ItemStack(OtherThings.money, (DARKSTEEL_VALUE * current.stackSize)));
			}
		}
		return true;
	}

}
