package com.tvaalex.alexcraft.blocks;

import java.util.Random;

import com.tvaalex.alexcraft.AlexCraft;
import com.tvaalex.alexcraft.AlexiumThings;
import com.tvaalex.alexcraft.CobaltThings;
import com.tvaalex.alexcraft.DarkSteelThings;
import com.tvaalex.alexcraft.ElekiumThings;
import com.tvaalex.alexcraft.EnderiumThings;
import com.tvaalex.alexcraft.MinecraftiumThings;
import com.tvaalex.alexcraft.PalamaxThings;
import com.tvaalex.alexcraft.RainbowThings;
import com.tvaalex.alexcraft.SteelThings;
import com.tvaalex.alexcraft.SuperiumThings;

import ibxm.Player;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;

public class ACRainbowOre extends Block {

	public ACRainbowOre(Material material, String unlocalizedName) {
		super(material);
		this.setCreativeTab(AlexCraft.tabAlexCraftModOres);
		this.setBlockName(unlocalizedName);
		this.setBlockTextureName(AlexCraft.modid + ":" + unlocalizedName);
		this.setHardness(2.0F);
        this.setResistance(15.0F);
        this.setLightLevel(2.0F);
        this.setHarvestLevel("pickaxe", 3);
		// TODO Auto-generated constructor stub
	}
	
	public static Item randomItem(){
		if(Math.random() * 100 < 65) {
			return SteelThings.itemSteelIngot;
		}
		if(Math.random() * 100 < 47) {
			return CobaltThings.itemCobaltIngot;
		}
		if(Math.random() * 100 < 18) {
			return EnderiumThings.itemEnderiumIngot;
		}
		if(Math.random() * 100 < 18) {
			return AlexiumThings.itemAlexiumIngot;
		}
		if(Math.random() * 100 < 20) {
			return PalamaxThings.itemPalamaxIngot;
		}
		if(Math.random() * 100 < 46) {
			return ElekiumThings.itemElekiumIngot;
		}
		if(Math.random() * 100 < 22) {
			return DarkSteelThings.itemDarkSteelIngot;
		}
		if(Math.random() * 100 < 27) {
			return SuperiumThings.itemSuperiumIngot;
		}
		if(Math.random() * 100 < 13) {
			return RainbowThings.itemRainbowIngot;
		}
		if(Math.random() * 100 < 3) {
			return RainbowThings.rainbowSword;
		}
		if(Math.random() * 100 < 3) {
			return RainbowThings.rainbowPickaxe;
		}
		if(Math.random() * 100 < 1) {
			return MinecraftiumThings.itemMinecraftiumIngot;
		}
		return null;
	}
	
	@Override
	public int quantityDropped(Random rand) {
		int i = rand.nextInt(8) + 3;
		return i;
	}
	
	@Override
	public Item getItemDropped(int metadata, Random rand, int fortune) {
		return randomItem();
	}

}
