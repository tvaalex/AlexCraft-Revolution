package com.tvaalex.alexcraft.blocks;

import com.tvaalex.alexcraft.AlexCraft;

import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class DecorationRegistry {
	
	//Blocks
	//Dark Stone
	public static Block blockDarkStone;
	public static Block blockCrakeledDarkStone;
	public static Block blockCarvedDarkStone;
	
	//Light Stone
	public static Block blockLightStone;
	public static Block blockCrakeledLightStone;
	public static Block blockCarvedLightStone;
	
	//Neth Stone
	public static Block blockDarkNethStone;
	public static Block blockLightNethStone;
	
	//Quartz
	public static Block blockDarkSPolishedQuartz;
	public static Block blockLightSPolishedQuartz;
	
	//Caze Stone
	public static Block blockCazeStone;
	
	public static void LoadAll() {
		GameRegistry.registerBlock(blockDarkStone = new ACBlock(Material.rock, 2, 10.0F, 1000.0F).setBlockName("BlockDarkStone").setBlockTextureName(AlexCraft.modid + ":BlockDarkStone"), blockDarkStone.getUnlocalizedName().substring(5));
		GameRegistry.registerBlock(blockCrakeledDarkStone = new ACBlock(Material.rock, 2, 10.0F, 1000.0F).setBlockName("BlockCrakeledDarkStone").setBlockTextureName(AlexCraft.modid + ":BlockCrakeledDarkStone"), blockCrakeledDarkStone.getUnlocalizedName().substring(5));
		GameRegistry.registerBlock(blockCarvedDarkStone = new ACBlock(Material.rock, 2, 10.0F, 1000.0F).setBlockName("BlockCarvedDarkStone").setBlockTextureName(AlexCraft.modid + ":BlockCarvedDarkStone"), blockCarvedDarkStone.getUnlocalizedName().substring(5));
		GameRegistry.registerBlock(blockLightStone = new ACBlock(Material.rock, 2, 10.0F, 1000.0F).setBlockName("BlockLightStone").setBlockTextureName(AlexCraft.modid + ":BlockLightStone"), blockLightStone.getUnlocalizedName().substring(5));
		GameRegistry.registerBlock(blockCrakeledLightStone = new ACBlock(Material.rock, 2, 10.0F, 1000.0F).setBlockName("BlockCrakeledLightStone").setBlockTextureName(AlexCraft.modid + ":BlockCrakeledLightStone"), blockCrakeledLightStone.getUnlocalizedName().substring(5));
		GameRegistry.registerBlock(blockCarvedLightStone = new ACBlock(Material.rock, 2, 10.0F, 1000.0F).setBlockName("BlockCarvedLightStone").setBlockTextureName(AlexCraft.modid + ":BlockCarvedLightStone"), blockCarvedLightStone.getUnlocalizedName().substring(5));
		GameRegistry.registerBlock(blockDarkNethStone = new ACBlock(Material.rock, 2, 10.0F, 1000.0F).setBlockName("BlockDarkNethStone").setBlockTextureName(AlexCraft.modid + ":BlockDarkNethStone"), blockDarkNethStone.getUnlocalizedName().substring(5));
		GameRegistry.registerBlock(blockLightNethStone = new ACBlock(Material.rock, 2, 10.0F, 1000.0F).setBlockName("BlockLightNethStone").setBlockTextureName(AlexCraft.modid + ":BlockLightNethStone"), blockLightNethStone.getUnlocalizedName().substring(5));
		GameRegistry.registerBlock(blockDarkSPolishedQuartz = new ACBlock(Material.ice, 2, 10.0F, 1000.0F).setBlockName("BlockDarkSPolishedQuartz").setBlockTextureName(AlexCraft.modid + ":BlockDarkSPolishedQuartz"), blockDarkSPolishedQuartz.getUnlocalizedName().substring(5));
		GameRegistry.registerBlock(blockLightSPolishedQuartz = new ACBlock(Material.ice, 2, 10.0F, 1000.0F).setBlockName("BlockLightSPolishedQuartz").setBlockTextureName(AlexCraft.modid + ":BlockLightSPolishedQuartz"), blockLightSPolishedQuartz.getUnlocalizedName().substring(5));
		GameRegistry.registerBlock(blockCazeStone = new ACBlock(Material.rock, 2, 10.0F, 1000.0F).setBlockName("BlockCazeStone").setBlockTextureName(AlexCraft.modid + ":BlockCazeStone"), blockCazeStone.getUnlocalizedName().substring(5));
	}

}
