package com.tvaalex.alexcraft.blocks.tnt;

import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.block.Block;
import net.minecraft.block.BlockTNT;

public class TNTRegistry {
	
	public static Block novaBomb;
	
	public static void LoadAll() {
		GameRegistry.registerBlock(novaBomb = new ACTNT("NovaBomb", 335.0F), novaBomb.getUnlocalizedName().substring(5));
	}

}
