package com.tvaalex.alexcraft.blocks;

import java.util.Random;

import com.tvaalex.alexcraft.AlexCraft;
import com.tvaalex.alexcraft.AlexiumThings;
import com.tvaalex.alexcraft.CobaltThings;
import com.tvaalex.alexcraft.DarkSteelThings;
import com.tvaalex.alexcraft.ElekiumThings;
import com.tvaalex.alexcraft.EnderiumThings;
import com.tvaalex.alexcraft.MinecraftiumThings;
import com.tvaalex.alexcraft.MineralsThings;
import com.tvaalex.alexcraft.PalamaxThings;
import com.tvaalex.alexcraft.RainbowThings;
import com.tvaalex.alexcraft.SteelThings;
import com.tvaalex.alexcraft.SuperiumThings;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.item.Item;

public class ACMineralizedDirt extends Block {
	
	public ACMineralizedDirt(String unlo) {
		super(Material.grass);
		this.setBlockName(unlo);
		this.setBlockTextureName(AlexCraft.modid + ":" + unlo);
		this.setHardness(1);
		this.setResistance(1);
		this.setHarvestLevel("pickaxe", 2);
		// TODO Auto-generated constructor stub
	}

	public static Item randomItem(){
		//Common
		if(Math.random() * 100 < 90) {
			return MineralsThings.mineraliteShard;
		}
		if(Math.random() * 100 < 80) {
			return MineralsThings.verdiberiteShard;
		}
		//Rare
		if(Math.random() * 100 < 40) {
			return MineralsThings.blueberiteShard;
		}
		if(Math.random() * 100 < 30) {
			return MineralsThings.maviriteShard;
		}
		if(Math.random() * 100 < 20) {
			return MineralsThings.razoriteShard;
		}
		if(Math.random() * 100 < 10) {
			return MineralsThings.supragolderiteShard;
		}
		return null;
	}
	
	@Override
	public int quantityDropped(Random rand) {
		int i = rand.nextInt(5) + 3;
		return i;
	}
	
	@Override
	public Item getItemDropped(int metadata, Random rand, int fortune) {
		return randomItem();
	}


}
