package com.tvaalex.alexcraft.blocks;

import com.tvaalex.alexcraft.AlexCraft;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class UpgradeBlock extends Block {

	public UpgradeBlock(String unlo) {
		super(Material.iron);
		this.setBlockName(unlo);
		this.setBlockTextureName(AlexCraft.modid + ":" + this.getUnlocalizedName().substring(5));
		this.setCreativeTab(AlexCraft.tabAlexCraftModUtilities);
		// TODO Auto-generated constructor stub
	}
	
	

}
