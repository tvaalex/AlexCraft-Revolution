package com.tvaalex.alexcraft.blocks;

import com.tvaalex.alexcraft.AlexCraft;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class ACBlock extends Block {

	public ACBlock(Material material, int harvestLevel, float hardeness, float resistance) {
		super(material);
		this.setBlockTextureName(AlexCraft.modid + ":" + this.getUnlocalizedName().substring(5));
		this.setHarvestLevel("pickaxe", harvestLevel);
		this.setHardness(hardeness);
		this.setResistance(resistance);
		this.setCreativeTab(AlexCraft.tabAlexCraftModBlocks);
		// TODO Auto-generated constructor stub
	}
	
	

}
