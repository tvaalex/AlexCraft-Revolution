package com.tvaalex.alexcraft.blocks;

import com.tvaalex.alexcraft.AlexCraft;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class ACXRayBlock extends Block{

	public ACXRayBlock(Material material, String unlocalizedName) {
		super(material);
		this.setBlockName(unlocalizedName);
		this.setBlockTextureName(AlexCraft.modid + ":" + unlocalizedName);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public boolean isOpaqueCube() {
		return true;
	}

}
