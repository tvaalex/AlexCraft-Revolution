package com.tvaalex.alexcraft.blocks.tileentity;

import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;

public abstract class ACBlockTileEntity extends BlockContainer{
    public ACBlockTileEntity(Material material){
        super(material);
    }

    public ACBlockTileEntity(){
        this(Material.rock);
    }

}
