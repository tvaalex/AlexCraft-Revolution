package com.tvaalex.alexcraft.blocks.multiblocks;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

import com.tvaalex.alexcraft.tileentity.TileEntityModularStorage;
import com.tvaalex.alexcraft.utility.Log;
import com.tvaalex.alexcraft.AlexCraft;
import com.tvaalex.alexcraft.blocks.tileentity.ACBlockTileEntity;

public class ACModularStorageMultiBlock extends ACBlockTileEntity{

    public ACModularStorageMultiBlock(String unlocalizedName){
        this.setBlockName(unlocalizedName);
        this.setBlockTextureName(AlexCraft.modid + ":" + unlocalizedName);
    }

    @Override
    public TileEntity createNewTileEntity(World p_149915_1_, int p_149915_2_){
        return new TileEntityModularStorage();
    }

    @Override
    public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int side, float hitX, float hitY, float hitZ){
        if(!world.isRemote) {
            TileEntityModularStorage storage = (TileEntityModularStorage)world.getTileEntity(x, y, z);
            TileEntityModularStorage master = storage.getMaster();
            Log.info("master storage:");
            for(int i = 0; i < master.getSizeInventory(); i++) {
                Log.info(i + ", " + master.getStackInSlot(i));
            }
        }
        return true;
    }

}
