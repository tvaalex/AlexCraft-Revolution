package com.tvaalex.alexcraft.blocks;

import java.util.Random;

import com.tvaalex.alexcraft.AlexCraft;
import com.tvaalex.alexcraft.OtherThings;
import com.tvaalex.alexcraft.items.ACIngot;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class ACDuplicator extends Block {

	public static int durability;
	
	public ACDuplicator() {
		super(Material.iron);
		this.setBlockName("DuplicatorBlock");
		this.setBlockTextureName(AlexCraft.modid + ":" + this.getUnlocalizedName().substring(5));
		this.durability = 96;
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int side, float hitX,
			float hitY, float hitZ) {

		if (!world.isRemote) {
			int dupliUpgradeNb = 1;
			int costUpgradeNb = 1;
			int heatLevel = 13;
			boolean ingotUpgrade = false;
			boolean blockUpgrade = false;
			boolean unstackableUpgrade = false;

			for (int i = 12; i > 0; i--) {
				if (world.getBlock(x + i, y, z) == OtherThings.duplicationUpgrade) {
					dupliUpgradeNb++;
				}

				if (world.getBlock(x - i, y, z) == OtherThings.costUpgrade) {
					costUpgradeNb++;
				}

				if (world.getBlock(x, y, z + i) == Blocks.water) {
					heatLevel--;
				}

				if (world.getBlock(x, y + i, z) == OtherThings.blockUpgrade) {
					blockUpgrade = true;
				}

				if (world.getBlock(x, y + i, z) == OtherThings.ingotUpgrade) {
					ingotUpgrade = true;
				}
				
				if (world.getBlock(x, y + i, z) == OtherThings.unstackableUpgrade) {
					unstackableUpgrade = true;
				}

			}
			System.out.println("[Duplicator -> Cost Upgrades]: " + (costUpgradeNb - 1));
			System.out.println("[Duplicator -> Duplication Upgrades]: " + (dupliUpgradeNb - 1));
			System.out.println("[Duplicator -> Heat Level]: " + heatLevel);

			if (player.inventory.hasItem(OtherThings.goldCoins)) {
				Item current = player.inventory.getCurrentItem().getItem();
				Random random = new Random();

				int a = 0;
				for (int i = 0; i < (64 / costUpgradeNb); i++) {
					player.inventory.consumeInventoryItem(OtherThings.goldCoins);
					a = i;
				}

				System.out.println("[Duplicator -> Removed coins]: " + (a));

				if (Math.random() * 100 < 40 && current != OtherThings.goldCoins) {
					if ((ingotUpgrade && current instanceof ACIngot) || (blockUpgrade && current.getUnlocalizedName().startsWith("tile.")) || (unstackableUpgrade && current.getItemStackLimit() < 2)) {
						player.inventory.addItemStackToInventory(new ItemStack(current, (dupliUpgradeNb) + 1));
						System.out.println("[Duplicator -> Added Items to player: " + player.getDisplayName() + "]: "
								+ current.getUnlocalizedName() + ": " + (dupliUpgradeNb - 1));
					} else if ((!ingotUpgrade && current instanceof ACIngot)
							|| (!blockUpgrade && current.getUnlocalizedName().startsWith("tile.")) || (!unstackableUpgrade && current.getItemStackLimit() < 2)) {
						System.out.println("[Duplicator -> Can't add Items to player: " + player.getDisplayName()
								+ "]: Not enough upgrades");
					} else {
						player.inventory.addItemStackToInventory(new ItemStack(current, (dupliUpgradeNb) + 1));
						System.out.println("[Duplicator -> Added Items to player: " + player.getDisplayName() + "]: "
								+ current.getUnlocalizedName() + ": " + (dupliUpgradeNb + 1));
					}

				}else {
					System.out.println("[Duplicator -> No chance]");
				}

			}
			
			this.durability -= heatLevel;

			if (this.durability <= 0) {
				world.setBlock(x, y, z, Blocks.air);
				player.playSound("dig.stone", 75.0F, 75.0F);
				player.playSound("dig.glass", 75.0F, 75.0F);
			} else {
				System.out.println("[Duplicator -> Durability: " + this.durability);
			}
			Random rand = new Random();
			for (int i = 0; i < (rand.nextInt(30) + 12); i++) {
				if (durability <= 24) {
					world.spawnParticle("smoke", x, y + 1, z, 0, 0, 0);
				} else if (durability >= 24 && heatLevel < 3) {
					world.spawnParticle("dripWater", x, y + 1, z, 0, 0, 0);
				} else if (durability <= 24 && heatLevel > 3) {
					world.spawnParticle("flame", x, y + 1, z, 0, 0, 0);
				} else if (durability >= 24 && heatLevel > 3) {
					world.spawnParticle("spell", x, y + 1, z, 0, 0, 0);
				}
			}
		}
		return true;
	}
}