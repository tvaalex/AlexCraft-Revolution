package com.tvaalex.alexcraft.blocks;

import java.util.Random;

import com.tvaalex.alexcraft.AlexCraft;
import com.tvaalex.alexcraft.AlexiumThings;
import com.tvaalex.alexcraft.CobaltThings;
import com.tvaalex.alexcraft.DarkSteelThings;
import com.tvaalex.alexcraft.ElekiumThings;
import com.tvaalex.alexcraft.EnderiumThings;
import com.tvaalex.alexcraft.MinecraftiumThings;
import com.tvaalex.alexcraft.PalamaxThings;
import com.tvaalex.alexcraft.RainbowThings;
import com.tvaalex.alexcraft.SteelThings;
import com.tvaalex.alexcraft.SuperiumThings;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.item.Item;

public class ACZacCrate extends Block {

	public ACZacCrate(Material material, String unlocalizedName) {
		super(material);
		this.setCreativeTab(AlexCraft.tabAlexCraftModOres);
		this.setBlockName(unlocalizedName);
		this.setBlockTextureName(AlexCraft.modid + ":" + unlocalizedName);
		this.setHardness(2.0F);
        this.setResistance(15.0F);
        this.setLightLevel(2.0F);
        this.setHarvestLevel("pickaxe", 3);
		// TODO Auto-generated constructor stub
	}
	
	public static Item randomItem(){
		if(Math.random() * 100 < 45) {
			return SteelThings.itemSteelIngot;
		}
		if(Math.random() * 100 < 38) {
			return CobaltThings.itemCobaltIngot;
		}
		if(Math.random() * 100 < 17) {
			return EnderiumThings.itemEnderiumIngot;
		}
		if(Math.random() * 100 < 16) {
			return AlexiumThings.itemAlexiumIngot;
		}
		if(Math.random() * 100 < 19) {
			return PalamaxThings.itemPalamaxIngot;
		}
		if(Math.random() * 100 < 38) {
			return ElekiumThings.itemElekiumIngot;
		}
		if(Math.random() * 100 < 22) {
			return DarkSteelThings.itemDarkSteelIngot;
		}
		if(Math.random() * 100 < 20) {
			return SuperiumThings.itemSuperiumIngot;
		}
		if(Math.random() * 100 < 17) {
			return RainbowThings.itemRainbowIngot;
		}
		if(Math.random() * 100 < 15) {
			return RainbowThings.rainbowSword;
		}
		if(Math.random() * 100 < 10) {
			return RainbowThings.rainbowPickaxe;
		}
		if(Math.random() * 100 < 6) {
			return MinecraftiumThings.itemMinecraftiumIngot;
		}
		if(Math.random() * 100 < 2) {
			return MinecraftiumThings.minecraftiumSword;
		}
		if(Math.random() * 100 < 2) {
			return MinecraftiumThings.minecraftiumPickaxe;
		}
		return null;
	}
	
	@Override
	public int quantityDropped(Random rand) {
		int i = rand.nextInt(24) + 5;
		return i;
	}
	
	@Override
	public Item getItemDropped(int metadata, Random rand, int fortune) {
		return randomItem();
	}

}
