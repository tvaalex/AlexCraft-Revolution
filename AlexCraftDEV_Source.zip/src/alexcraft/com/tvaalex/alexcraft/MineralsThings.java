package com.tvaalex.alexcraft;

import com.tvaalex.alexcraft.blocks.ACMineralizedDirt;
import com.tvaalex.alexcraft.items.ACItem;

import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.block.Block;
import net.minecraft.item.Item;

public class MineralsThings {
	
	public static Block mineralizedDirt;
	//Minerals
	public static Item mineraliteShard;
	public static Item verdiberiteShard;
	public static Item blueberiteShard;
	public static Item maviriteShard;
	public static Item razoriteShard;
	public static Item supragolderiteShard;
	//Ores
	public static Item azuliteIngot;
	public static Item magikiumIngot;
	public static Item paradoxiumIngot;
	public static Item zirikiumIngot;
	//Mashed Ores
	public static Item megalitiumIngot;
	public static Item iridiumIngot;
	//Super Ore
	public static Item mekalitiumIngot;
	
	public static void LoadAll() {
		GameRegistry.registerBlock(mineralizedDirt = new ACMineralizedDirt("MineralizedDirt").setCreativeTab(AlexCraft.tabAlexCraftModBlocks), mineralizedDirt.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(mineraliteShard = new ACItem().setUnlocalizedName("MineraliteShard").setCreativeTab(AlexCraft.tabAlexCraftModOres), mineraliteShard.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(verdiberiteShard = new ACItem().setUnlocalizedName("VerdiberiteShard").setCreativeTab(AlexCraft.tabAlexCraftModOres), verdiberiteShard.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(blueberiteShard = new ACItem().setUnlocalizedName("BlueberiteShard").setCreativeTab(AlexCraft.tabAlexCraftModOres), blueberiteShard.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(maviriteShard = new ACItem().setUnlocalizedName("MaviriteShard").setCreativeTab(AlexCraft.tabAlexCraftModOres), maviriteShard.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(razoriteShard = new ACItem().setUnlocalizedName("RazoriteShard").setCreativeTab(AlexCraft.tabAlexCraftModOres), razoriteShard.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(supragolderiteShard = new ACItem().setUnlocalizedName("SupragolderiteShard").setCreativeTab(AlexCraft.tabAlexCraftModOres), supragolderiteShard.getUnlocalizedName().substring(5));
	}
	
}
