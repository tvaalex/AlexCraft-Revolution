package com.tvaalex.alexcraft;

import com.tvaalex.alexcraft.biomes.BiomesRegistry;
import com.tvaalex.alexcraft.blocks.DecorationRegistry;
import com.tvaalex.alexcraft.blocks.tnt.TNTRegistry;
import com.tvaalex.alexcraft.entity.ACEntity;
import com.tvaalex.alexcraft.handlers.KeyInputHandler;
import com.tvaalex.alexcraft.items.electronical.ElectronicalRegistry;
import com.tvaalex.alexcraft.items.enchants.EnchantmentRegistry;
import com.tvaalex.alexcraft.items.entity.grenades.GrenadesRegistry;
import com.tvaalex.alexcraft.items.food.FoodRegistry;
import com.tvaalex.alexcraft.items.guns.GunsRegistry;
import com.tvaalex.alexcraft.items.tools.ACArrow;
import com.tvaalex.alexcraft.items.tools.ACDaggerThrowed;
import com.tvaalex.alexcraft.keybinding.KeyBindings;
import com.tvaalex.alexcraft.proxy.CommonProxy;
import com.tvaalex.alexcraft.proxy.ServerProxy;

import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.Mod.Instance;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPostInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EntityDamageSourceIndirect;

@Mod(modid = AlexCraft.modid, name = AlexCraft.modName, version = AlexCraft.modVersion)
public class AlexCraft {
	
	public static final String modid = "ac";
	public static final String modName = "AlexCraft Revolution";
	public static final String modVersion = "PreAlpha";
	
	public static final String CLIENT_PROXY_CLASS = "com.tvaalex.alexcraft.proxy.ClientProxy";
    public static final String SERVER_PROXY_CLASS = "com..tvaalex.alexcraft.proxy.ServerProxy";
	
	@SidedProxy(clientSide = CLIENT_PROXY_CLASS, serverSide = SERVER_PROXY_CLASS)
	public static CommonProxy proxy;
	

	@EventHandler
	public void preInit(FMLPreInitializationEvent event) {
		//Item/Block Init and Registering
		//Config Handling
		proxy.preInit();
		SploutchThings.LoadAll();
		SteelThings.LoadAll();
		EnderiumThings.LoadAll();
		AlexiumThings.LoadAll();
		SuperiumThings.LoadAll();
		ElekiumThings.loadAll();
		CobaltThings.LoadAll();
		PalamaxThings.LoadAll();
		DarkSteelThings.LoadAll();
		MinecraftiumThings.LoadAll();
		MineralsThings.LoadAll();
		LegendaryWeaponsRegistry.register();
		FoodRegistry.LoadAll();
		DecorationRegistry.LoadAll();
		GunsRegistry.LoadAll();
		ElectronicalRegistry.LoadAll();
		MagicalRegistry.LoadAll();
		TNTRegistry.LoadAll();
		BiomesRegistry.init();
		GrenadesRegistry.loadGrenades();
		ACEntity.mainRegistry();
		OtherThings.LoadAll();
		RainbowThings.LoadAll();
	}
	
	@EventHandler
	public void init(FMLInitializationEvent event) {
		//Proxy, TileEntity, entity, GUI and Packet Registering
		
		GameRegistry.registerWorldGenerator(new ACOreGeneration(), 0);
		FMLCommonHandler.instance().bus().register(new KeyInputHandler());
		KeyBindings.init();
	}
	
	@EventHandler
	public void postInit(FMLPostInitializationEvent event) {
		
	}
	
	public static CreativeTabs tabAlexCraftModOres = new CreativeTabs("tabAlexCraftModOres") {
		@Override
		public Item getTabIconItem() {
			return new ItemStack(SteelThings.itemSteelIngot).getItem();
		}

	};
	
	public static CreativeTabs tabAlexCraftModUtilities = new CreativeTabs("tabAlexCraftModUtilities") {
		@Override
		public Item getTabIconItem() {
			return new ItemStack(OtherThings.multiBlockModularStorage).getItem();
		}

	};
	
	public static CreativeTabs tabAlexCraftModElectronical = new CreativeTabs("TabAlexCraftModElectronical") {
		@Override
		public Item getTabIconItem() {
			return new ItemStack(ElectronicalRegistry.computerCardSciFi).getItem();
		}
	};
	
	public static CreativeTabs tabAlexCraftModToolsAndWeapons = new CreativeTabs("tabAlexCraftModToolsAndWeapons") {
		@Override
		public Item getTabIconItem() {
			return new ItemStack(OtherThings.magicalSword).getItem();
		}
	};
	
	public static CreativeTabs tabAlexCraftModArmors = new CreativeTabs("tabAlexCraftModArmors") {
		@Override
		public Item getTabIconItem() {
			return new ItemStack(CobaltThings.cobaltHeavyChestplate).getItem();
		}
	};
	
	public static CreativeTabs tabAlexCraftModFood = new CreativeTabs("tabAlexCraftModFood") {
		@Override
		public Item getTabIconItem() {
			return new ItemStack(FoodRegistry.itemHoneyMelonFood).getItem();
		}
	};
	
	public static CreativeTabs tabAlexCraftModBlocks = new CreativeTabs("tabAlexCraftModBlocks") {
		@Override
		public Item getTabIconItem() {
			return new ItemStack(AlexiumThings.blockAlexiumBlock).getItem();
		}
	};
	
	@Instance(modid)
	public static AlexCraft modInstance;
	
	public static DamageSource causeACArrowDamage(ACArrow p_76353_0_, Entity p_76353_1_)
    {
        return (new EntityDamageSourceIndirect("arrow", p_76353_0_, p_76353_1_)).setProjectile();
    }
	
	public static DamageSource causeDaggerDamage(ACDaggerThrowed p_76353_0_, Entity p_76353_1_)
    {
        return (new EntityDamageSourceIndirect("dagger", p_76353_0_, p_76353_1_)).setProjectile();
    }
}
