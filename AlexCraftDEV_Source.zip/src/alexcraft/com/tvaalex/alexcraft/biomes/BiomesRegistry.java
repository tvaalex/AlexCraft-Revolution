package com.tvaalex.alexcraft.biomes;

import net.minecraft.world.biome.BiomeGenBase;
import net.minecraftforge.common.BiomeDictionary;
import net.minecraftforge.common.BiomeDictionary.Type;
import net.minecraftforge.common.BiomeManager;
import net.minecraftforge.common.BiomeManager.BiomeEntry;

public class BiomesRegistry {
	
	public static BiomeGenBase biomeBlueHeaven;
	public static BiomeGenBase biomePollutedLand;
	public static void init() {
		registerBiomes();
	}
	
	public static void registerBiomes() {
		
		biomeBlueHeaven = new BiomeBlueHeaven(50).setBiomeName("Blue Biome");
		BiomeDictionary.registerBiomeType(biomeBlueHeaven, Type.HILLS);
		BiomeManager.icyBiomes.add(new BiomeEntry(biomeBlueHeaven, 10));
		
		biomePollutedLand = new BiomePollutedLand(51).setBiomeName("Blue Biome");
		BiomeDictionary.registerBiomeType(biomePollutedLand, Type.SPOOKY);
		BiomeManager.desertBiomes.add(new BiomeEntry(biomePollutedLand, 11));
		
		BiomeManager.addSpawnBiome(biomeBlueHeaven);
	}

}
