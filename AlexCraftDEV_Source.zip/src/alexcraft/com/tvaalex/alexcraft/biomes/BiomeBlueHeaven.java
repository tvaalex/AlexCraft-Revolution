package com.tvaalex.alexcraft.biomes;

import net.minecraft.world.biome.BiomeGenBase;
import net.minecraftforge.event.terraingen.BiomeEvent.GetFoliageColor;

public class BiomeBlueHeaven extends BiomeGenBase{
	
	private static final Height biomeHeight = new Height(0.1F, 0.3F);

	public BiomeBlueHeaven(int id) {
		super(id);
		
		this.setHeight(biomeHeight);
		this.setColor(4048127);
		this.setTemperatureRainfall(1.0F, 2.5F);
		this.createMutation();
		this.enableSnow = false;
		this.enableRain = false;
		this.waterColorMultiplier = 16268799;
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public int getBiomeGrassColor(int x, int y, int z) {
		return 4048127;
		
	}
	
	@Override
	public int getBiomeFoliageColor(int x, int y, int z) {
		return 11477224;
	}
	
	@Override
	public int getSkyColorByTemp(float par1) {
		return 1;
	}

}
