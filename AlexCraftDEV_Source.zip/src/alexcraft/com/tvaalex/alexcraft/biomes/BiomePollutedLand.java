package com.tvaalex.alexcraft.biomes;

import net.minecraft.world.biome.BiomeGenBase;
import net.minecraftforge.event.terraingen.BiomeEvent.GetFoliageColor;

public class BiomePollutedLand extends BiomeGenBase{
	
	private static final Height biomeHeight = new Height(0.0003F, 0.15F);

	public BiomePollutedLand(int id) {
		super(id);
		
		this.setHeight(biomeHeight);
		this.setColor(16744448);
		this.setTemperatureRainfall(1.0F, 2.5F);
		this.createMutation();
		this.enableSnow = false;
		this.enableRain = true;
		this.waterColorMultiplier = 1245210;
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public int getBiomeGrassColor(int x, int y, int z) {
		return 16744448;
		
	}
	
	@Override
	public int getBiomeFoliageColor(int x, int y, int z) {
		return 8408320;
	}
	
	@Override
	public int getSkyColorByTemp(float par1) {
		return 0;
	}

}
