package com.tvaalex.alexcraft;

import com.tvaalex.alexcraft.items.ACIngot;
import com.tvaalex.alexcraft.items.food.ACRainbowMelon;
import com.tvaalex.alexcraft.items.tools.ACPick;
import com.tvaalex.alexcraft.items.tools.ACSword;

import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.util.EnumHelper;

public class RainbowThings {
	
	public static Item rainbowSword;
	public static Item rainbowPickaxe;
	public static Item itemRainbowMelonFood;
	public static Item itemRainbowIngot;
	
	public static final Item.ToolMaterial rainbowToolMaterial = EnumHelper.addToolMaterial("RainbowToolMaterial", 4, 3000, 6.0F, 7.0F, 1000);
	
	public static void LoadAll() {
		GameRegistry.registerItem(rainbowSword = new ACSword("RainbowSword", rainbowToolMaterial), rainbowSword.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(rainbowPickaxe = new ACPick("RainbowPickaxe", rainbowToolMaterial), rainbowPickaxe.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(itemRainbowIngot = new ACIngot().setUnlocalizedName("ItemRainbowIngot"), itemRainbowIngot.getUnlocalizedName().substring(5));
		GameRegistry.addRecipe(new ItemStack(OtherThings.blockRainbowOre, 48), new Object[] {"XXX", "XZX", "XXX", 'X', Blocks.stone, 'Z', itemRainbowIngot});
		GameRegistry.registerItem(itemRainbowMelonFood = new ACRainbowMelon("ItemRainbowMelonFood", 6, 1.4F, true), itemRainbowMelonFood.getUnlocalizedName().substring(5));
	}

}
