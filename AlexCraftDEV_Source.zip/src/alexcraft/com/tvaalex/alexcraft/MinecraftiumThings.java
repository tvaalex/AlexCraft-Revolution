package com.tvaalex.alexcraft;

import com.tvaalex.alexcraft.blocks.ACBlock;
import com.tvaalex.alexcraft.items.ACIngot;
import com.tvaalex.alexcraft.items.ACItem;
import com.tvaalex.alexcraft.items.Tetrax;
import com.tvaalex.alexcraft.items.tools.ACAxe;
import com.tvaalex.alexcraft.items.tools.ACBow;
import com.tvaalex.alexcraft.items.tools.ACHammer;
import com.tvaalex.alexcraft.items.tools.ACMultiTool;
import com.tvaalex.alexcraft.items.tools.ACPick;
import com.tvaalex.alexcraft.items.tools.ACSword;
import com.tvaalex.alexcraft.items.tools.ACTetraxedS;

import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor.ArmorMaterial;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.util.EnumHelper;

public class MinecraftiumThings {
	
	public static Item itemMinecraftiumOrb;
	public static Item itemMinecraftiumIngot;
	public static Item itemMinecraftiumStick;
	public static Item tetrax;
	
	public static final Item.ToolMaterial minecraftiumToolMaterial = EnumHelper.addToolMaterial("MinecraftiumToolMaterial", 5, 1000000, 25.0F, 102.5F, 1000000000);
	public static Item minecraftiumSword;
	public static Item minecraftiumPickaxe;
	public static Item minecraftiumAxe;
	public static Item minecraftiumMultiTool;
	public static Item minecraftiumBow;
	public static Item minecraftiumHammer;
	public static Item tetraxedSword;
	
	public static final ArmorMaterial minecraftiumArmorMaterial = EnumHelper.addArmorMaterial("MinecraftiumArmorMaterial", 102, new int[]{25, 35, 26, 24}, 30);
	public static Item minecraftiumHelmet;
	public static Item minecraftiumChestplate;
	public static Item minecraftiumLeggings;
	public static Item minecraftiumBoots;
	
	
	public static Block blockMinecraftiumBlock;

	
	public static void LoadAll() {
		//Blocks
		GameRegistry.registerBlock(blockMinecraftiumBlock = new ACBlock(Material.iron, 2, 10.0F, 1000.0F).setBlockName("BlockMinecraftiumBlock").setBlockTextureName(AlexCraft.modid + ":BlockMinecraftiumBlock"), blockMinecraftiumBlock.getUnlocalizedName().substring(5));
				
		GameRegistry.registerItem(tetrax = new Tetrax("Tetrax").setCreativeTab(AlexCraft.tabAlexCraftModToolsAndWeapons), tetrax.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(itemMinecraftiumIngot = new ACIngot().setUnlocalizedName("ItemMinecraftiumIngot").setCreativeTab(AlexCraft.tabAlexCraftModOres), itemMinecraftiumIngot.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(itemMinecraftiumStick = new ACItem().setUnlocalizedName("ItemMinecraftiumStick"), itemMinecraftiumStick.getUnlocalizedName().substring(5));
		GameRegistry.addRecipe(new ItemStack(itemMinecraftiumStick), "   ", "X#X", "   ", 'X', itemMinecraftiumIngot, '#', Items.stick);
		
		//Tools N Weapons!
		GameRegistry.registerItem(minecraftiumPickaxe = new ACPick("MinecraftiumPickaxe", minecraftiumToolMaterial).setCreativeTab(AlexCraft.tabAlexCraftModToolsAndWeapons), minecraftiumPickaxe.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(minecraftiumSword = new ACSword("MinecraftiumSword", minecraftiumToolMaterial).setCreativeTab(AlexCraft.tabAlexCraftModToolsAndWeapons), minecraftiumSword.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(minecraftiumBow = new ACBow("MinecraftiumBow", 24.562F, 1000000).setCreativeTab(AlexCraft.tabAlexCraftModToolsAndWeapons), minecraftiumBow.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(minecraftiumAxe = new ACAxe("MinecraftiumAxe", minecraftiumToolMaterial).setCreativeTab(AlexCraft.tabAlexCraftModToolsAndWeapons), minecraftiumAxe.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(minecraftiumMultiTool = new ACMultiTool("MinecraftiumMultiTool", minecraftiumToolMaterial).setCreativeTab(AlexCraft.tabAlexCraftModToolsAndWeapons), minecraftiumMultiTool.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(minecraftiumHammer = new ACHammer("MinecraftiumHammer", minecraftiumToolMaterial), minecraftiumHammer.getUnlocalizedName().substring(5));
		GameRegistry.addRecipe(new ItemStack(minecraftiumPickaxe), "XXX", " # ", " # ", 'X', itemMinecraftiumIngot, '#', itemMinecraftiumStick);
		GameRegistry.addRecipe(new ItemStack(minecraftiumAxe), "XX ", "X# ", " # ", 'X', itemMinecraftiumIngot, '#', itemMinecraftiumStick);
		GameRegistry.addRecipe(new ItemStack(minecraftiumSword), " X ", " X ", " # ", 'X', itemMinecraftiumIngot, '#', itemMinecraftiumStick);
		GameRegistry.addRecipe(new ItemStack(minecraftiumMultiTool), "ZXZ", " # ", " # ", 'X', itemMinecraftiumIngot, '#', itemMinecraftiumStick, 'Z', blockMinecraftiumBlock);
		//Tetraxed
		GameRegistry.registerItem(tetraxedSword = new ACTetraxedS("TetraxedSword", minecraftiumToolMaterial).setCreativeTab(AlexCraft.tabAlexCraftModToolsAndWeapons), tetraxedSword.getUnlocalizedName().substring(5));

	}

}
