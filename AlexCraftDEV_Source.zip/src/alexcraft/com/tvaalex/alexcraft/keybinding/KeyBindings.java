package com.tvaalex.alexcraft.keybinding;

import org.lwjgl.input.Keyboard;
import cpw.mods.fml.client.registry.ClientRegistry;
import net.minecraft.client.settings.KeyBinding;

public class KeyBindings {
    public static KeyBinding water;
    public static KeyBinding fire;
    public static KeyBinding lightning;
    public static KeyBinding earth;
    public static KeyBinding light;
    public static KeyBinding darkness;


    public static void init() {
	    water = new KeyBinding("key.water", Keyboard.KEY_J, "key.categories.alexcraft");
	    ClientRegistry.registerKeyBinding(water);
	    
	    fire = new KeyBinding("key.fire", Keyboard.KEY_K, "key.categories.alexcraft");
	    ClientRegistry.registerKeyBinding(fire);
	    
	    lightning = new KeyBinding("key.lightning", Keyboard.KEY_L, "key.categories.alexcraft");
	    ClientRegistry.registerKeyBinding(lightning);
	    
	    earth = new KeyBinding("key.earth", Keyboard.KEY_B, "key.categories.alexcraft");
	    ClientRegistry.registerKeyBinding(earth);
	    
	    light = new KeyBinding("key.light", Keyboard.KEY_N, "key.categories.alexcraft");
	    ClientRegistry.registerKeyBinding(light);
	    
	    darkness = new KeyBinding("key.darkness", Keyboard.KEY_M, "key.categories.alexcraft");
	    ClientRegistry.registerKeyBinding(darkness);
    }
}