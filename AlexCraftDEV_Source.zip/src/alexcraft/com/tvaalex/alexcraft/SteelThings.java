package com.tvaalex.alexcraft;

import com.tvaalex.alexcraft.blocks.ACBlock;
import com.tvaalex.alexcraft.blocks.ACChest;
import com.tvaalex.alexcraft.items.ACIngot;
import com.tvaalex.alexcraft.items.ACItem;
import com.tvaalex.alexcraft.items.armor.ACArmor;
import com.tvaalex.alexcraft.items.tools.ACAxe;
import com.tvaalex.alexcraft.items.tools.ACDagger;
import com.tvaalex.alexcraft.items.tools.ACHammer;
import com.tvaalex.alexcraft.items.tools.ACHoe;
import com.tvaalex.alexcraft.items.tools.ACMultiTool;
import com.tvaalex.alexcraft.items.tools.ACPick;
import com.tvaalex.alexcraft.items.tools.ACShovel;
import com.tvaalex.alexcraft.items.tools.ACSword;

import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor.ArmorMaterial;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.util.EnumHelper;

public class SteelThings {
		//Steel Declarations
		//Items and Blocks
		public static Item itemSteelIngot;
		public static Item itemSteelHeavyIngot;
		public static Item itemSteelStick;
		public static Block blockSteelBlock;
		public static Block blockSteelOre;
		public static Block blockSteelCrate;
		//Materials
		public static final Item.ToolMaterial steelToolMaterial = EnumHelper.addToolMaterial("SteelToolMaterial", 2, 250, 6.0F, 1.8F, 30);   
		public static final ArmorMaterial steelArmorMaterial = EnumHelper.addArmorMaterial("SteelArmorMaterial", 9, new int[]{3, 5, 4, 2}, 30);
		public static final ArmorMaterial steelHeavyArmorMaterial = EnumHelper.addArmorMaterial("SteelHeavyArmorMaterial", 10, new int[]{4, 6, 5, 2}, 30);
		//Tools
		public static Item steelPickaxe;
		public static Item steelSword;
		public static Item steelAxe;
		public static Item steelShovel;
		public static Item steelHoe;
		public static Item steelMultiTool;
		public static Item steelHammer;
		public static Item steelDagger;
		//Armors
		public static Item steelHelmet;
		public static Item steelChestplate;
		public static Item steelLeggings;
		public static Item steelBoots;
		//Heavy Armors
		public static Item steelHeavyHelmet;
		public static Item steelHeavyChestplate;
		public static Item steelHeavyLeggings;
		public static Item steelHeavyBoots;
		
		public static void LoadAll() {
			//Steel Items and Block Init.
				//Steel Registry
				GameRegistry.registerItem(itemSteelIngot = new ACIngot().setUnlocalizedName("ItemSteelIngot"), itemSteelIngot.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(itemSteelHeavyIngot = new ACIngot().setUnlocalizedName("ItemSteelHeavyIngot"), itemSteelHeavyIngot.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(itemSteelStick = new ACItem().setUnlocalizedName("ItemSteelStick"), itemSteelStick.getUnlocalizedName().substring(5));
				GameRegistry.registerBlock(blockSteelBlock = new ACBlock(Material.iron, 2, 10.0F, 20.0F).setBlockName("BlockSteelBlock").setBlockTextureName(AlexCraft.modid + ":BlockSteelBlock"), blockSteelBlock.getUnlocalizedName().substring(5));
				GameRegistry.registerBlock(blockSteelOre = new ACBlock(Material.rock, 1, 20.0F, 45.0F).setBlockName("BlockSteelOre").setBlockTextureName(AlexCraft.modid + ":BlockSteelOre"), blockSteelOre.getUnlocalizedName().substring(5));
				GameRegistry.registerBlock(blockSteelCrate = new ACChest("BlockSteelCrate", 0).setBlockName("BlockSteelCrate").setBlockTextureName(AlexCraft.modid + ":BlockSteelCrate"), blockSteelCrate.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(steelPickaxe = new ACPick("SteelPickaxe", steelToolMaterial), steelPickaxe.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(steelHammer = new ACHammer("SteelHammer", steelToolMaterial), steelHammer.getUnlocalizedName().substring(5));
				GameRegistry.addRecipe(new ItemStack(steelPickaxe), new Object[] {"XXX", " # ", " # ", 'X', itemSteelHeavyIngot, '#', itemSteelStick});
				GameRegistry.registerItem(steelSword = new ACSword("SteelSword", steelToolMaterial), steelSword.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(steelAxe = new ACAxe("SteelAxe", steelToolMaterial), steelAxe.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(steelShovel = new ACShovel("SteelShovel", steelToolMaterial), steelShovel.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(steelDagger = new ACDagger("SteelDagger", 2.21F, steelToolMaterial), steelDagger.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(steelHoe = new ACHoe("SteelHoe", steelToolMaterial), steelHoe.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(steelMultiTool = new ACMultiTool("SteelMultiTool", steelToolMaterial), steelMultiTool.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(steelHelmet = new ACArmor("SteelHelmet", steelArmorMaterial, "SteelArmor", 0), steelHelmet.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(steelChestplate = new ACArmor("SteelChestplate", steelArmorMaterial, "SteelArmor", 1), steelChestplate.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(steelLeggings = new ACArmor("SteelLeggings", steelArmorMaterial, "SteelArmor", 2), steelLeggings.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(steelBoots = new ACArmor("SteelBoots", steelArmorMaterial, "SteelArmor", 3), steelBoots.getUnlocalizedName().substring(5));				
				GameRegistry.registerItem(steelHeavyHelmet = new ACArmor("SteelHeavyHelmet", steelHeavyArmorMaterial, "SteelHeavyArmor", 0), steelHeavyHelmet.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(steelHeavyChestplate = new ACArmor("SteelHeavyChestplate", steelHeavyArmorMaterial, "SteelHeavyArmor", 1), steelHeavyChestplate.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(steelHeavyLeggings = new ACArmor("SteelHeavyLeggings", steelHeavyArmorMaterial, "SteelHeavyArmor", 2), steelHeavyLeggings.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(steelHeavyBoots = new ACArmor("SteelHeavyBoots", steelHeavyArmorMaterial, "SteelHeavyArmor", 3), steelHeavyBoots.getUnlocalizedName().substring(5));
				//Steel Crafting Recipies
				//Blocks and Items
				GameRegistry.addRecipe(new ItemStack(itemSteelStick), new Object[] {"   ", "X#X", "   ", 'X', itemSteelIngot, '#', Items.stick});
				GameRegistry.addRecipe(new ItemStack(steelPickaxe), new Object[] {"XXX", " # ", " # ", 'X', itemSteelIngot, '#', itemSteelStick});
				GameRegistry.addRecipe(new ItemStack(steelAxe), new Object[] {"XX ", "X# ", " # ", 'X', itemSteelIngot, '#', itemSteelStick});
				GameRegistry.addRecipe(new ItemStack(steelSword), new Object[] {" X ", " X ", " # ", 'X', itemSteelIngot, '#', itemSteelStick});
				GameRegistry.addRecipe(new ItemStack(steelShovel), new Object[] {" X ", " # ", " # ", 'X', itemSteelIngot, '#', itemSteelStick});
				GameRegistry.addRecipe(new ItemStack(steelHoe), new Object[] {" XX", " # ", " # ", 'X', itemSteelIngot, '#', itemSteelStick});
				GameRegistry.addRecipe(new ItemStack(steelMultiTool), new Object[] {"ZXZ", " # ", " # ", 'X', itemSteelIngot, '#', itemSteelStick, 'Z', blockSteelBlock});
				GameRegistry.addRecipe(new ItemStack(blockSteelBlock), new Object[] {"XXX", "XXX", "XXX", 'X', itemSteelIngot});
				GameRegistry.addShapelessRecipe(new ItemStack(itemSteelIngot, 9), new Object[] {blockSteelBlock});
				GameRegistry.addRecipe(new ItemStack(itemSteelHeavyIngot), new Object[] {"   ", " XX", " XX", 'X', itemSteelIngot});
				GameRegistry.addShapelessRecipe(new ItemStack(itemSteelIngot, 4), new Object[] {itemSteelHeavyIngot});
				GameRegistry.addRecipe(new ItemStack(steelHelmet), new Object[] {"XXX", "X X", "   ", 'X', itemSteelIngot});
				GameRegistry.addRecipe(new ItemStack(steelChestplate), new Object[] {"X X", "XXX", "XXX", 'X', itemSteelIngot});
				GameRegistry.addRecipe(new ItemStack(steelLeggings), new Object[] {"XXX", "X X", "X X", 'X', itemSteelIngot});
				GameRegistry.addRecipe(new ItemStack(steelBoots), new Object[] {"   ", "X X", "X X", 'X', itemSteelIngot});
				GameRegistry.addRecipe(new ItemStack(steelHeavyHelmet), new Object[] {"XZX", "X X", "   ", 'X', itemSteelIngot,'Z', blockSteelBlock});
				GameRegistry.addRecipe(new ItemStack(steelHeavyChestplate), new Object[] {"X X", "XZX", "XXX", 'X', itemSteelIngot, 'Z', blockSteelBlock});
				GameRegistry.addRecipe(new ItemStack(steelHeavyLeggings), new Object[] {"XZX", "X X", "X X", 'X', itemSteelIngot, 'Z', blockSteelBlock});
				GameRegistry.addRecipe(new ItemStack(steelHeavyBoots), new Object[] {"X X", "X X", "X X", 'X', itemSteelIngot});
				//Steel Smelting Recipies
				GameRegistry.addSmelting(blockSteelOre, new ItemStack(itemSteelIngot), 0.5F);

					
		}

}
