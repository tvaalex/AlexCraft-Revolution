package com.tvaalex.alexcraft;

import com.tvaalex.alexcraft.blocks.ACBlock;
import com.tvaalex.alexcraft.items.ACIngot;

import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class DarkSteelThings {
	
	public static Item itemDarkSteelIngot;
	public static Item itemSuperDarkSteelIngot;
	public static Block blockDarkSteelBlock;
	public static Item darkSteelSword;
	
	public static void LoadAll() {
		GameRegistry.registerItem(itemDarkSteelIngot = new ACIngot().setUnlocalizedName("ItemDarkSteelIngot"), itemDarkSteelIngot.getUnlocalizedName().substring(5));
		GameRegistry.addRecipe(new ItemStack(itemDarkSteelIngot), new Object[] {"ZXZ", "XYX", "ZXZ",'X', SteelThings.itemSteelIngot, 'Y', Items.diamond, 'Z', Items.coal});
		GameRegistry.registerItem(itemSuperDarkSteelIngot = new ACIngot().setUnlocalizedName("ItemSuperDarkSteelIngot"), itemSuperDarkSteelIngot.getUnlocalizedName().substring(5));
		GameRegistry.addRecipe(new ItemStack(itemSuperDarkSteelIngot), new Object[] {"XXX", "XYX", "XXX",'X', itemDarkSteelIngot, 'Y', Blocks.obsidian});
		GameRegistry.registerBlock(blockDarkSteelBlock = new ACBlock(Material.dragonEgg, 3, 100, 4000).setBlockName("BlockDarkSteelBlock"), blockDarkSteelBlock.getUnlocalizedName().substring(5));
		GameRegistry.addSmelting(itemSuperDarkSteelIngot, new ItemStack(blockDarkSteelBlock), 10);
	}

}
