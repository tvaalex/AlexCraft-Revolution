package com.tvaalex.alexcraft;

import com.tvaalex.alexcraft.blocks.ACBlock;
import com.tvaalex.alexcraft.items.ACItem;
import com.tvaalex.alexcraft.items.tools.ACMultiTool;
import com.tvaalex.alexcraft.items.tools.ACSword;

import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.util.EnumHelper;

public class SploutchThings {
	
	public static Item sploutch;
	public static Block compactedSploutchBlockTier1;
	public static Block compactedSploutchBlockTier2;
	public static Block compactedSploutchBlockTier3;
	public static Block compactedSploutchBlockTier4;
	public static Block compactedSploutchBlockTier5;
	public static Block compactedSploutchBlockTier6;
	public static Block compactedSploutchBlockTier7;
	public static Block compactedSploutchBlockTier8;
	//Swords
	public static Item sploutchSwordTier1;
	public static Item sploutchSwordTier2;
	public static Item sploutchSwordTier3;
	public static Item sploutchSwordTier4;
	public static Item sploutchSwordTier5;
	public static Item sploutchSwordTier6;
	public static Item sploutchSwordTier7;
	public static Item sploutchSwordTier8;
	//Pickaxe
	public static Item sploutchPickaxeTier1;
	public static Item sploutchPickaxeTier2;
	public static Item sploutchPickaxeTier3;
	public static Item sploutchPickaxeTier4;
	public static Item sploutchPickaxeTier5;
	public static Item sploutchPickaxeTier6;
	public static Item sploutchPickaxeTier7;
	public static Item sploutchPickaxeTier8;
	//Tool materials
	public static final Item.ToolMaterial sploutchTier1 = EnumHelper.addToolMaterial("sploutchTier1", 1, 100, 1.0F, 0.5F, 10);
	public static final Item.ToolMaterial sploutchTier2 = EnumHelper.addToolMaterial("sploutchTier2", 1, 200, 2.0F, 1.0F, 20);
	public static final Item.ToolMaterial sploutchTier3 = EnumHelper.addToolMaterial("sploutchTier3", 2, 600, 3.0F, 1.5F, 30);
	public static final Item.ToolMaterial sploutchTier4 = EnumHelper.addToolMaterial("sploutchTier4", 2, 800, 4.0F, 2.0F, 40);
	public static final Item.ToolMaterial sploutchTier5 = EnumHelper.addToolMaterial("sploutchTier5", 3, 1000, 5.0F, 2.5F, 50);
	public static final Item.ToolMaterial sploutchTier6 = EnumHelper.addToolMaterial("sploutchTier6", 3, 1200, 6.0F, 3.0F, 60);
	public static final Item.ToolMaterial sploutchTier7 = EnumHelper.addToolMaterial("sploutchTier7", 4, 1400, 8.0F, 3.5F, 70);
	public static final Item.ToolMaterial sploutchTier8 = EnumHelper.addToolMaterial("sploutchTier8", 4, 1600, 10.0F, 4.0F, 80);
	
	public static void LoadAll() {
		GameRegistry.registerItem(sploutch = new ACItem().setUnlocalizedName("Sploutch"), sploutch.getUnlocalizedName().substring(5));
		GameRegistry.addShapelessRecipe(new ItemStack(sploutch, 3), new Object[] {Items.slime_ball, Items.snowball});
		
		GameRegistry.registerBlock(compactedSploutchBlockTier1 = new ACBlock(Material.snow, 1, 1.0F, 1.0F).setBlockName("CompactedSploutchBlockTier1"), compactedSploutchBlockTier1.getUnlocalizedName().substring(5));
		GameRegistry.addShapelessRecipe(new ItemStack(compactedSploutchBlockTier1), new Object[] {new ItemStack(sploutch, 4)});
		GameRegistry.registerItem(sploutchSwordTier1 = new ACSword("SploutchSwordTier1", sploutchTier1), sploutchSwordTier1.getUnlocalizedName().substring(5));
		GameRegistry.addRecipe(new ItemStack(sploutchSwordTier1), new Object[] {" X ", " X ", " Y ", 'X', compactedSploutchBlockTier1, 'Y', Items.stick});
		GameRegistry.registerItem(sploutchPickaxeTier1 = new ACMultiTool("SploutchPickaxeTier1", sploutchTier1), sploutchPickaxeTier1.getUnlocalizedName().substring(5));
		GameRegistry.addRecipe(new ItemStack(sploutchPickaxeTier1), new Object[] {"XXX", " Y ", " Y ", 'X', compactedSploutchBlockTier1, 'Y', Items.stick});
		
		GameRegistry.registerBlock(compactedSploutchBlockTier2 = new ACBlock(Material.snow, 2, 2.0F, 2.0F).setBlockName("CompactedSploutchBlockTier2"), compactedSploutchBlockTier2.getUnlocalizedName().substring(5));
		GameRegistry.addShapelessRecipe(new ItemStack(compactedSploutchBlockTier2), new Object[] {new ItemStack(compactedSploutchBlockTier1, 4)});
		GameRegistry.registerItem(sploutchSwordTier2 = new ACSword("SploutchSwordTier2", sploutchTier2), sploutchSwordTier2.getUnlocalizedName().substring(5));
		GameRegistry.addRecipe(new ItemStack(sploutchSwordTier2), new Object[] {" X ", " X ", " Y ", 'X', compactedSploutchBlockTier2, 'Y', Items.stick});
		GameRegistry.registerItem(sploutchPickaxeTier2 = new ACMultiTool("SploutchPickaxeTier2", sploutchTier2), sploutchPickaxeTier2.getUnlocalizedName().substring(5));
		GameRegistry.addRecipe(new ItemStack(sploutchPickaxeTier2), new Object[] {"XXX", " Y ", " Y ", 'X', compactedSploutchBlockTier2, 'Y', Items.stick});
		
		GameRegistry.registerBlock(compactedSploutchBlockTier3 = new ACBlock(Material.snow, 3, 3.0F, 3.0F).setBlockName("CompactedSploutchBlockTier3"), compactedSploutchBlockTier3.getUnlocalizedName().substring(5));
		GameRegistry.addShapelessRecipe(new ItemStack(compactedSploutchBlockTier3), new Object[] {new ItemStack(compactedSploutchBlockTier2, 4)});
		GameRegistry.registerItem(sploutchSwordTier3 = new ACSword("SploutchSwordTier3", sploutchTier3), sploutchSwordTier3.getUnlocalizedName().substring(5));
		GameRegistry.addRecipe(new ItemStack(sploutchSwordTier3), new Object[] {" X ", " X ", " Y ", 'X', compactedSploutchBlockTier3, 'Y', Items.stick});
		GameRegistry.registerItem(sploutchPickaxeTier3 = new ACMultiTool("SploutchPickaxeTier3", sploutchTier3), sploutchPickaxeTier3.getUnlocalizedName().substring(5));
		GameRegistry.addRecipe(new ItemStack(sploutchPickaxeTier3), new Object[] {"XXX", " Y ", " Y ", 'X', compactedSploutchBlockTier3, 'Y', Items.stick});
		
		GameRegistry.registerBlock(compactedSploutchBlockTier4 = new ACBlock(Material.snow, 4, 4.0F, 4.0F).setBlockName("CompactedSploutchBlockTier4"), compactedSploutchBlockTier4.getUnlocalizedName().substring(5));
		GameRegistry.addShapelessRecipe(new ItemStack(compactedSploutchBlockTier4), new Object[] {new ItemStack(compactedSploutchBlockTier3, 4)});
		GameRegistry.registerItem(sploutchSwordTier4 = new ACSword("SploutchSwordTier4", sploutchTier4), sploutchSwordTier4.getUnlocalizedName().substring(5));
		GameRegistry.addRecipe(new ItemStack(sploutchSwordTier4), new Object[] {" X ", " X ", " Y ", 'X', compactedSploutchBlockTier4, 'Y', Items.stick});
		GameRegistry.registerItem(sploutchPickaxeTier4 = new ACMultiTool("SploutchPickaxeTier4", sploutchTier4), sploutchPickaxeTier4.getUnlocalizedName().substring(5));
		GameRegistry.addRecipe(new ItemStack(sploutchPickaxeTier4), new Object[] {"XXX", " Y ", " Y ", 'X', compactedSploutchBlockTier4, 'Y', Items.stick});
		
		GameRegistry.registerBlock(compactedSploutchBlockTier5 = new ACBlock(Material.snow, 5, 5.0F, 5.0F).setBlockName("CompactedSploutchBlockTier5"), compactedSploutchBlockTier5.getUnlocalizedName().substring(5));
		GameRegistry.addShapelessRecipe(new ItemStack(compactedSploutchBlockTier5), new Object[] {new ItemStack(compactedSploutchBlockTier4, 4)});
		GameRegistry.registerItem(sploutchSwordTier5 = new ACSword("SploutchSwordTier5", sploutchTier5), sploutchSwordTier5.getUnlocalizedName().substring(5));
		GameRegistry.addRecipe(new ItemStack(sploutchSwordTier5), new Object[] {" X ", " X ", " Y ", 'X', compactedSploutchBlockTier5, 'Y', Items.stick});
		GameRegistry.registerItem(sploutchPickaxeTier5 = new ACMultiTool("SploutchPickaxeTier5", sploutchTier5), sploutchPickaxeTier5.getUnlocalizedName().substring(5));
		GameRegistry.addRecipe(new ItemStack(sploutchPickaxeTier5), new Object[] {"XXX", " Y ", " Y ", 'X', compactedSploutchBlockTier5, 'Y', Items.stick});
		
		GameRegistry.registerBlock(compactedSploutchBlockTier6 = new ACBlock(Material.snow, 6, 6.0F, 6.0F).setBlockName("CompactedSploutchBlockTier6"), compactedSploutchBlockTier6.getUnlocalizedName().substring(6));
		GameRegistry.addShapelessRecipe(new ItemStack(compactedSploutchBlockTier6), new Object[] {new ItemStack(compactedSploutchBlockTier5, 4)});
		GameRegistry.registerItem(sploutchSwordTier6 = new ACSword("SploutchSwordTier6", sploutchTier6), sploutchSwordTier6.getUnlocalizedName().substring(6));
		GameRegistry.addRecipe(new ItemStack(sploutchSwordTier6), new Object[] {" X ", " X ", " Y ", 'X', compactedSploutchBlockTier6, 'Y', Items.stick});
		GameRegistry.registerItem(sploutchPickaxeTier6 = new ACMultiTool("SploutchPickaxeTier6", sploutchTier6), sploutchPickaxeTier6.getUnlocalizedName().substring(6));
		GameRegistry.addRecipe(new ItemStack(sploutchPickaxeTier6), new Object[] {"XXX", " Y ", " Y ", 'X', compactedSploutchBlockTier6, 'Y', Items.stick});
		
		GameRegistry.registerBlock(compactedSploutchBlockTier7 = new ACBlock(Material.snow, 7, 7.0F, 7.0F).setBlockName("CompactedSploutchBlockTier7"), compactedSploutchBlockTier7.getUnlocalizedName().substring(7));
		GameRegistry.addShapelessRecipe(new ItemStack(compactedSploutchBlockTier7), new Object[] {new ItemStack(compactedSploutchBlockTier6, 4)});
		GameRegistry.registerItem(sploutchSwordTier7 = new ACSword("SploutchSwordTier7", sploutchTier7), sploutchSwordTier7.getUnlocalizedName().substring(7));
		GameRegistry.addRecipe(new ItemStack(sploutchSwordTier7), new Object[] {" X ", " X ", " Y ", 'X', compactedSploutchBlockTier7, 'Y', Items.stick});
		GameRegistry.registerItem(sploutchPickaxeTier7 = new ACMultiTool("SploutchPickaxeTier7", sploutchTier7), sploutchPickaxeTier7.getUnlocalizedName().substring(7));
		GameRegistry.addRecipe(new ItemStack(sploutchPickaxeTier7), new Object[] {"XXX", " Y ", " Y ", 'X', compactedSploutchBlockTier7, 'Y', Items.stick});
		
		GameRegistry.registerBlock(compactedSploutchBlockTier8 = new ACBlock(Material.snow, 8, 8.0F, 8.0F).setBlockName("CompactedSploutchBlockTier8"), compactedSploutchBlockTier8.getUnlocalizedName().substring(8));
		GameRegistry.addShapelessRecipe(new ItemStack(compactedSploutchBlockTier8), new Object[] {new ItemStack(compactedSploutchBlockTier7, 4)});
		GameRegistry.registerItem(sploutchSwordTier8 = new ACSword("SploutchSwordTier8", sploutchTier8), sploutchSwordTier8.getUnlocalizedName().substring(8));
		GameRegistry.addRecipe(new ItemStack(sploutchSwordTier8), new Object[] {" X ", " X ", " Y ", 'X', compactedSploutchBlockTier8, 'Y', Items.stick});
		GameRegistry.registerItem(sploutchPickaxeTier8 = new ACMultiTool("SploutchPickaxeTier8", sploutchTier8), sploutchPickaxeTier8.getUnlocalizedName().substring(8));
		GameRegistry.addRecipe(new ItemStack(sploutchPickaxeTier8), new Object[] {"XXX", " Y ", " Y ", 'X', compactedSploutchBlockTier8, 'Y', Items.stick});
	}
}
