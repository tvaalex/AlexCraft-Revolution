package com.tvaalex.alexcraft;

import com.tvaalex.alexcraft.blocks.ACBlock;
import com.tvaalex.alexcraft.items.ACIngot;
import com.tvaalex.alexcraft.items.ACItem;

import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class ElekiumThings {
	
	//Items
	public static Item itemElekiumIngot;
	public static Item itemBasicElekiumCircut;
	public static Item itemAdvancedElekiumCircut;
	public static Item itemElekiumCore;
	//Blocks
	public static Block blockElekiumOre;
	
	public static void loadAll() {
		//Items
		GameRegistry.registerItem(itemElekiumIngot = new ACIngot().setUnlocalizedName("ItemElekiumIngot"), itemElekiumIngot.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(itemBasicElekiumCircut = new ACItem().setUnlocalizedName("ItemBasicElekiumCircut").setCreativeTab(AlexCraft.tabAlexCraftModElectronical), itemBasicElekiumCircut.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(itemAdvancedElekiumCircut = new ACItem().setUnlocalizedName("ItemAdvancedElekiumCircut").setCreativeTab(AlexCraft.tabAlexCraftModElectronical), itemAdvancedElekiumCircut.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(itemElekiumCore = new ACItem().setUnlocalizedName("ItemElekiumCore").setCreativeTab(AlexCraft.tabAlexCraftModElectronical), itemElekiumCore.getUnlocalizedName().substring(5));
		//Blocks
		GameRegistry.registerBlock(blockElekiumOre = new ACBlock(Material.rock, 2, 10.0F, 50.0F).setBlockName("BlockElekiumOre"), blockElekiumOre.getUnlocalizedName().substring(5));
		//Crafting and Smelting
		GameRegistry.addSmelting(blockElekiumOre, new ItemStack(itemElekiumIngot), 10.0F);
		GameRegistry.addRecipe(new ItemStack(itemBasicElekiumCircut), new Object[] {" X ", "X#X", " X ", 'X', itemElekiumIngot, '#', Items.diamond});
		GameRegistry.addRecipe(new ItemStack(itemAdvancedElekiumCircut), new Object[] {" X ", "X#X", " X ", 'X', itemElekiumIngot, '#', itemElekiumCore});
		GameRegistry.addRecipe(new ItemStack(itemElekiumCore), new Object[] {"X#X","X#X", "X#X", 'X', itemElekiumIngot, '#', SteelThings.itemSteelIngot});

	}

}
