package com.tvaalex.alexcraft.proxy;

import com.tvaalex.alexcraft.AlexCraft;
import cpw.mods.fml.common.network.NetworkRegistry;
import net.minecraft.entity.player.EntityPlayer;

public class ServerProxy extends CommonProxy{

    @Override
    public void preInit(){

    }

    @Override
    public void init(){

    }

    @Override
    public void postInit(){

    }

    @Override
    public EntityPlayer getClientPlayer(){
        return null;
    }
    
}
