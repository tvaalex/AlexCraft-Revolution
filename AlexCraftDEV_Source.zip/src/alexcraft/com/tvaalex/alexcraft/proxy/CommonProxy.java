package com.tvaalex.alexcraft.proxy;

import com.tvaalex.alexcraft.items.guns.Ammo;
import com.tvaalex.alexcraft.items.guns.RenderAmmo;

import cpw.mods.fml.client.registry.RenderingRegistry;
import net.minecraft.entity.player.EntityPlayer;

public  class CommonProxy{

	public void preInit() {
		// TODO Auto-generated method stub
		
	}

	public void init() {
		// TODO Auto-generated method stub
		
	}

	public void postInit() {
		// TODO Auto-generated method stub
		
	}

	public EntityPlayer getClientPlayer() {
		// TODO Auto-generated method stub
		return null;
	}
}
