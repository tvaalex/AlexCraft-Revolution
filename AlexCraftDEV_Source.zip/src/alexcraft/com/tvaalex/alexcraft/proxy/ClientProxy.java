package com.tvaalex.alexcraft.proxy;

import com.tvaalex.alexcraft.SteelThings;
import com.tvaalex.alexcraft.items.guns.Ammo;
import com.tvaalex.alexcraft.items.guns.RenderAmmo;
import com.tvaalex.alexcraft.items.tools.ACArrow;
import com.tvaalex.alexcraft.items.tools.ACDaggerThrowed;
import com.tvaalex.alexcraft.items.tools.RenderACArrow;
import com.tvaalex.alexcraft.items.tools.RenderDagger;

import cpw.mods.fml.client.registry.ClientRegistry;
import cpw.mods.fml.client.registry.RenderingRegistry;
import cpw.mods.fml.common.FMLCommonHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.RenderSnowball;
import net.minecraft.entity.player.EntityPlayer;

public class ClientProxy extends CommonProxy{
	
public void registerRenderThings() {
		
		RenderingRegistry.registerEntityRenderingHandler(Ammo.class, new RenderAmmo());
		RenderingRegistry.registerEntityRenderingHandler(ACArrow.class, new RenderACArrow());
		RenderingRegistry.registerEntityRenderingHandler(ACDaggerThrowed.class, new RenderDagger());
	
	}
	
    public void preInit(){
        registerRenderThings();
    }


    public void init(){

    }

    public void postInit(){

    }

    public EntityPlayer getClientPlayer(){
        return Minecraft.getMinecraft().thePlayer;
    }

}
