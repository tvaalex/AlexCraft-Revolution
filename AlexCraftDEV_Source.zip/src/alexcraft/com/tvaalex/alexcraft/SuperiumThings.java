package com.tvaalex.alexcraft;

import com.tvaalex.alexcraft.blocks.ACBlock;
import com.tvaalex.alexcraft.blocks.ACChest;
import com.tvaalex.alexcraft.items.ACIngot;
import com.tvaalex.alexcraft.items.ACItem;
import com.tvaalex.alexcraft.items.armor.ACArmor;
import com.tvaalex.alexcraft.items.tools.ACAxe;
import com.tvaalex.alexcraft.items.tools.ACBow;
import com.tvaalex.alexcraft.items.tools.ACHammer;
import com.tvaalex.alexcraft.items.tools.ACHoe;
import com.tvaalex.alexcraft.items.tools.ACMultiTool;
import com.tvaalex.alexcraft.items.tools.ACPick;
import com.tvaalex.alexcraft.items.tools.ACShovel;
import com.tvaalex.alexcraft.items.tools.ACSword;

import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor.ArmorMaterial;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.util.EnumHelper;

public class SuperiumThings {
		//Superium Declarations
		//Items and Blocks
		public static Item itemSuperiumIngot;
		public static Item itemSuperiumHeavyIngot;
		public static Item itemSuperiumStick;
		public static Block blockSuperiumBlock;
		public static Block blockSuperiumOre;
		//Materials
		public static final Item.ToolMaterial superiumToolMaterial = EnumHelper.addToolMaterial("SuperiumToolMaterial", 3, 1500, 4.5F, 3.0F, 120);   
		public static final ArmorMaterial superiumArmorMaterial = EnumHelper.addArmorMaterial("SuperiumArmorMaterial", 11, new int[]{4, 7, 6, 3}, 120);
		public static final ArmorMaterial superiumHeavyArmorMaterial = EnumHelper.addArmorMaterial("SuperiumHeavyArmorMaterial", 15, new int[]{5, 7, 6, 4}, 120);
		//Tools
		public static Item superiumPickaxe;
		public static Item superiumSword;
		public static Item superiumAxe;
		public static Item superiumShovel;
		public static Item superiumHoe;
		public static Item superiumMultiTool;
		public static Item superiumHammer;
		public static Item superiumBow;
		//Armors
		public static Item superiumHelmet;
		public static Item superiumChestplate;
		public static Item superiumLeggings;
		public static Item superiumBoots;
		//Heavy Armors
		public static Item superiumHeavyHelmet;
		public static Item superiumHeavyChestplate;
		public static Item superiumHeavyLeggings;
		public static Item superiumHeavyBoots;
		
		public static void LoadAll() {
			//Superium Items and Block Init.
				//Superium Registry
				GameRegistry.registerItem(itemSuperiumIngot = new ACIngot().setUnlocalizedName("ItemSuperiumIngot"), itemSuperiumIngot.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(itemSuperiumHeavyIngot = new ACIngot().setUnlocalizedName("ItemSuperiumHeavyIngot"), itemSuperiumHeavyIngot.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(itemSuperiumStick = new ACItem().setUnlocalizedName("ItemSuperiumStick"), itemSuperiumStick.getUnlocalizedName().substring(5));
				GameRegistry.registerBlock(blockSuperiumBlock = new ACBlock(Material.iron, 2, 10.0F, 20.0F).setBlockName("BlockSuperiumBlock").setBlockTextureName(AlexCraft.modid + ":BlockSuperiumBlock"), blockSuperiumBlock.getUnlocalizedName().substring(5));
				GameRegistry.registerBlock(blockSuperiumOre = new ACBlock(Material.rock, 2, 20.0F, 45.0F).setBlockName("BlockSuperiumOre").setBlockTextureName(AlexCraft.modid + ":BlockSuperiumOre"), blockSuperiumOre.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(superiumPickaxe = new ACPick("SuperiumPickaxe", superiumToolMaterial), superiumPickaxe.getUnlocalizedName().substring(5));
				GameRegistry.addRecipe(new ItemStack(superiumPickaxe), new Object[] {"XXX", " # ", " # ", 'X', itemSuperiumHeavyIngot, '#', itemSuperiumStick});
				GameRegistry.registerItem(superiumSword = new ACSword("SuperiumSword", superiumToolMaterial), superiumSword.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(superiumAxe = new ACAxe("SuperiumAxe", superiumToolMaterial), superiumAxe.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(superiumShovel = new ACShovel("SuperiumShovel", superiumToolMaterial), superiumShovel.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(superiumHoe = new ACHoe("SuperiumHoe", superiumToolMaterial), superiumHoe.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(superiumMultiTool = new ACMultiTool("SuperiumMultiTool", superiumToolMaterial), superiumMultiTool.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(superiumHammer = new ACHammer("SuperiumHammer", superiumToolMaterial), superiumHammer.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(superiumBow = new ACBow("SuperiumBow", 24.562F, 1000000).setCreativeTab(AlexCraft.tabAlexCraftModToolsAndWeapons), superiumBow.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(superiumHelmet = new ACArmor("SuperiumHelmet", superiumArmorMaterial, "SuperiumArmor", 0), superiumHelmet.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(superiumChestplate = new ACArmor("SuperiumChestplate", superiumArmorMaterial, "SuperiumArmor", 1), superiumChestplate.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(superiumLeggings = new ACArmor("SuperiumLeggings", superiumArmorMaterial, "SuperiumArmor", 2), superiumLeggings.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(superiumBoots = new ACArmor("SuperiumBoots", superiumArmorMaterial, "SuperiumArmor", 3), superiumBoots.getUnlocalizedName().substring(5));				
				GameRegistry.registerItem(superiumHeavyHelmet = new ACArmor("SuperiumHeavyHelmet", superiumHeavyArmorMaterial, "SuperiumHeavyArmor", 0), superiumHeavyHelmet.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(superiumHeavyChestplate = new ACArmor("SuperiumHeavyChestplate", superiumHeavyArmorMaterial, "SuperiumHeavyArmor", 1), superiumHeavyChestplate.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(superiumHeavyLeggings = new ACArmor("SuperiumHeavyLeggings", superiumHeavyArmorMaterial, "SuperiumHeavyArmor", 2), superiumHeavyLeggings.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(superiumHeavyBoots = new ACArmor("SuperiumHeavyBoots", superiumHeavyArmorMaterial, "SuperiumHeavyArmor", 3), superiumHeavyBoots.getUnlocalizedName().substring(5));
				//Superium Crafting Recipies
				//Blocks and Items
				GameRegistry.addRecipe(new ItemStack(itemSuperiumStick), new Object[] {"   ", "X#X", "   ", 'X', itemSuperiumIngot, '#', Items.stick});
				GameRegistry.addRecipe(new ItemStack(superiumPickaxe), new Object[] {"XXX", " # ", " # ", 'X', itemSuperiumIngot, '#', itemSuperiumStick});
				GameRegistry.addRecipe(new ItemStack(superiumAxe), new Object[] {"XX ", "X# ", " # ", 'X', itemSuperiumIngot, '#', itemSuperiumStick});
				GameRegistry.addRecipe(new ItemStack(superiumSword), new Object[] {" X ", " X ", " # ", 'X', itemSuperiumIngot, '#', itemSuperiumStick});
				GameRegistry.addRecipe(new ItemStack(superiumShovel), new Object[] {" X ", " # ", " # ", 'X', itemSuperiumIngot, '#', itemSuperiumStick});
				GameRegistry.addRecipe(new ItemStack(superiumHoe), new Object[] {" XX", " # ", " # ", 'X', itemSuperiumIngot, '#', itemSuperiumStick});
				GameRegistry.addRecipe(new ItemStack(superiumMultiTool), new Object[] {"ZXZ", " # ", " # ", 'X', itemSuperiumIngot, '#', itemSuperiumStick, 'Z', blockSuperiumBlock});
				GameRegistry.addRecipe(new ItemStack(blockSuperiumBlock), new Object[] {"XXX", "XXX", "XXX", 'X', itemSuperiumIngot});
				GameRegistry.addShapelessRecipe(new ItemStack(itemSuperiumIngot, 9), new Object[] {blockSuperiumBlock});
				GameRegistry.addRecipe(new ItemStack(itemSuperiumHeavyIngot), new Object[] {"   ", " XX", " XX", 'X', itemSuperiumIngot});
				GameRegistry.addShapelessRecipe(new ItemStack(itemSuperiumIngot, 4), new Object[] {itemSuperiumHeavyIngot});
				GameRegistry.addRecipe(new ItemStack(superiumHelmet), new Object[] {"XXX", "X X", "   ", 'X', itemSuperiumIngot});
				GameRegistry.addRecipe(new ItemStack(superiumChestplate), new Object[] {"X X", "XXX", "XXX", 'X', itemSuperiumIngot});
				GameRegistry.addRecipe(new ItemStack(superiumLeggings), new Object[] {"XXX", "X X", "X X", 'X', itemSuperiumIngot});
				GameRegistry.addRecipe(new ItemStack(superiumBoots), new Object[] {"   ", "X X", "X X", 'X', itemSuperiumIngot});
				GameRegistry.addRecipe(new ItemStack(superiumHeavyHelmet), new Object[] {"XZX", "X X", "   ", 'X', itemSuperiumIngot,'Z', blockSuperiumBlock});
				GameRegistry.addRecipe(new ItemStack(superiumHeavyChestplate), new Object[] {"X X", "XZX", "XXX", 'X', itemSuperiumIngot, 'Z', blockSuperiumBlock});
				GameRegistry.addRecipe(new ItemStack(superiumHeavyLeggings), new Object[] {"XZX", "X X", "X X", 'X', itemSuperiumIngot, 'Z', blockSuperiumBlock});
				GameRegistry.addRecipe(new ItemStack(superiumHeavyBoots), new Object[] {"X X", "X X", "X X", 'X', itemSuperiumIngot});
				//Superium Smelting Recipies
				GameRegistry.addSmelting(blockSuperiumOre, new ItemStack(itemSuperiumIngot), 0.5F);

					
		}

}
