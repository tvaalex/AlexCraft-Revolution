package com.tvaalex.alexcraft;

import com.tvaalex.alexcraft.blocks.ACBlock;
import com.tvaalex.alexcraft.items.ACIngot;
import com.tvaalex.alexcraft.items.ACItem;
import com.tvaalex.alexcraft.items.armor.ACArmor;
import com.tvaalex.alexcraft.items.tools.ACAxe;
import com.tvaalex.alexcraft.items.tools.ACHammer;
import com.tvaalex.alexcraft.items.tools.ACHoe;
import com.tvaalex.alexcraft.items.tools.ACMultiTool;
import com.tvaalex.alexcraft.items.tools.ACPick;
import com.tvaalex.alexcraft.items.tools.ACShovel;
import com.tvaalex.alexcraft.items.tools.ACSword;

import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemArmor.ArmorMaterial;
import net.minecraftforge.common.util.EnumHelper;

public class CobaltThings {
		//Cobalt Declarations
		//Items and Blocks
		public static Item itemCobaltIngot;
		public static Item itemCobaltHeavyIngot;
		public static Item itemCobaltStick;
		public static Block blockCobaltBlock;
		public static Block blockCobaltOre;
		//Materials
		public static final Item.ToolMaterial cobaltToolMaterial = EnumHelper.addToolMaterial("CobaltToolMaterial", 2, 250, 6.0F, 1.8F, 30);   
		public static final ArmorMaterial cobaltArmorMaterial = EnumHelper.addArmorMaterial("CobaltArmorMaterial", 9, new int[]{3, 5, 4, 2}, 30);
		public static final ArmorMaterial cobaltHeavyArmorMaterial = EnumHelper.addArmorMaterial("CobaltHeavyArmorMaterial", 10, new int[]{4, 6, 5, 2}, 30);
		//Tools
		public static Item cobaltPickaxe;
		public static Item cobaltSword;
		public static Item cobaltAxe;
		public static Item cobaltShovel;
		public static Item cobaltHoe;
		public static Item cobaltMultiTool;
		public static Item cobaltHammer;
		//Armors
		public static Item cobaltHelmet;
		public static Item cobaltChestplate;
		public static Item cobaltLeggings;
		public static Item cobaltBoots;
		//Heavy Armors
		public static Item cobaltHeavyHelmet;
		public static Item cobaltHeavyChestplate;
		public static Item cobaltHeavyLeggings;
		public static Item cobaltHeavyBoots;
		
		public static void LoadAll() {
			//Cobalt Items and Block Init.
				//Cobalt Registry
				GameRegistry.registerItem(itemCobaltIngot = new ACIngot().setUnlocalizedName("ItemCobaltIngot"), itemCobaltIngot.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(itemCobaltHeavyIngot = new ACIngot().setUnlocalizedName("ItemCobaltHeavyIngot"), itemCobaltHeavyIngot.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(itemCobaltStick = new ACItem().setUnlocalizedName("ItemCobaltStick"), itemCobaltStick.getUnlocalizedName().substring(5));
				GameRegistry.registerBlock(blockCobaltBlock = new ACBlock(Material.iron, 2, 10.0F, 20.0F).setBlockName("BlockCobaltBlock").setBlockTextureName(AlexCraft.modid + ":BlockCobaltBlock"), blockCobaltBlock.getUnlocalizedName().substring(5));
				GameRegistry.registerBlock(blockCobaltOre = new ACBlock(Material.rock, 2, 17.5F, 34.0F).setBlockName("BlockCobaltOre").setBlockTextureName(AlexCraft.modid + ":BlockCobaltOre"), blockCobaltOre.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(cobaltPickaxe = new ACPick("CobaltPickaxe", cobaltToolMaterial), cobaltPickaxe.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(cobaltSword = new ACSword("CobaltSword", cobaltToolMaterial), cobaltSword.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(cobaltAxe = new ACAxe("CobaltAxe", cobaltToolMaterial), cobaltAxe.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(cobaltShovel = new ACShovel("CobaltShovel", cobaltToolMaterial), cobaltShovel.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(cobaltHoe = new ACHoe("CobaltHoe", cobaltToolMaterial), cobaltHoe.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(cobaltMultiTool = new ACMultiTool("CobaltMultiTool", cobaltToolMaterial), cobaltMultiTool.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(cobaltHammer = new ACHammer("CobaltHammer", cobaltToolMaterial), cobaltHammer.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(cobaltHelmet = new ACArmor("CobaltHelmet", cobaltArmorMaterial, "CobaltArmor", 0), cobaltHelmet.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(cobaltChestplate = new ACArmor("CobaltChestplate", cobaltArmorMaterial, "CobaltArmor", 1), cobaltChestplate.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(cobaltLeggings = new ACArmor("CobaltLeggings", cobaltArmorMaterial, "CobaltArmor", 2), cobaltLeggings.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(cobaltBoots = new ACArmor("CobaltBoots", cobaltArmorMaterial, "CobaltArmor", 3), cobaltBoots.getUnlocalizedName().substring(5));				
				GameRegistry.registerItem(cobaltHeavyHelmet = new ACArmor("CobaltHeavyHelmet", cobaltHeavyArmorMaterial, "CobaltHeavyArmor", 0), cobaltHeavyHelmet.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(cobaltHeavyChestplate = new ACArmor("CobaltHeavyChestplate", cobaltHeavyArmorMaterial, "CobaltHeavyArmor", 1), cobaltHeavyChestplate.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(cobaltHeavyLeggings = new ACArmor("CobaltHeavyLeggings", cobaltHeavyArmorMaterial, "CobaltHeavyArmor", 2), cobaltHeavyLeggings.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(cobaltHeavyBoots = new ACArmor("CobaltHeavyBoots", cobaltHeavyArmorMaterial, "CobaltHeavyArmor", 3), cobaltHeavyBoots.getUnlocalizedName().substring(5));
				//Cobalt Crafting Recipies
				//Blocks and Items
				GameRegistry.addRecipe(new ItemStack(itemCobaltStick), new Object[] {"   ", "X#X", "   ", 'X', itemCobaltIngot, '#', Items.stick});
				GameRegistry.addRecipe(new ItemStack(cobaltPickaxe), new Object[] {"XXX", " # ", " # ", 'X', itemCobaltIngot, '#', itemCobaltStick});
				GameRegistry.addRecipe(new ItemStack(cobaltAxe), new Object[] {"XX ", "X# ", " # ", 'X', itemCobaltIngot, '#', itemCobaltStick});
				GameRegistry.addRecipe(new ItemStack(cobaltSword), new Object[] {" X ", " X ", " # ", 'X', itemCobaltIngot, '#', itemCobaltStick});
				GameRegistry.addRecipe(new ItemStack(cobaltShovel), new Object[] {" X ", " # ", " # ", 'X', itemCobaltIngot, '#', itemCobaltStick});
				GameRegistry.addRecipe(new ItemStack(cobaltHoe), new Object[] {" XX", " # ", " # ", 'X', itemCobaltIngot, '#', itemCobaltStick});
				GameRegistry.addRecipe(new ItemStack(cobaltMultiTool), new Object[] {"ZXZ", " # ", " # ", 'X', itemCobaltIngot, '#', itemCobaltStick, 'Z', blockCobaltBlock});
				GameRegistry.addRecipe(new ItemStack(blockCobaltBlock), new Object[] {"XXX", "XXX", "XXX", 'X', itemCobaltIngot});
				GameRegistry.addShapelessRecipe(new ItemStack(itemCobaltIngot, 9), new Object[] {blockCobaltBlock});
				GameRegistry.addRecipe(new ItemStack(itemCobaltHeavyIngot), new Object[] {"   ", " XX", " XX", 'X', itemCobaltIngot});
				GameRegistry.addShapelessRecipe(new ItemStack(itemCobaltIngot, 4), new Object[] {itemCobaltHeavyIngot});
				GameRegistry.addRecipe(new ItemStack(cobaltHelmet), new Object[] {"XXX", "X X", "   ", 'X', itemCobaltIngot});
				GameRegistry.addRecipe(new ItemStack(cobaltChestplate), new Object[] {"X X", "XXX", "XXX", 'X', itemCobaltIngot});
				GameRegistry.addRecipe(new ItemStack(cobaltLeggings), new Object[] {"XXX", "X X", "X X", 'X', itemCobaltIngot});
				GameRegistry.addRecipe(new ItemStack(cobaltBoots), new Object[] {"   ", "X X", "X X", 'X', itemCobaltIngot});
				GameRegistry.addRecipe(new ItemStack(cobaltHeavyHelmet), new Object[] {"XZX", "X X", "   ", 'X', itemCobaltIngot,'Z', blockCobaltBlock});
				GameRegistry.addRecipe(new ItemStack(cobaltHeavyChestplate), new Object[] {"X X", "XZX", "XXX", 'X', itemCobaltIngot, 'Z', blockCobaltBlock});
				GameRegistry.addRecipe(new ItemStack(cobaltHeavyLeggings), new Object[] {"XZX", "X X", "X X", 'X', itemCobaltIngot, 'Z', blockCobaltBlock});
				GameRegistry.addRecipe(new ItemStack(cobaltHeavyBoots), new Object[] {"X X", "X X", "X X", 'X', itemCobaltIngot});
				//Cobalt Smelting Recipies
				GameRegistry.addSmelting(blockCobaltOre, new ItemStack(itemCobaltIngot), 0.5F);

					
		}

}
