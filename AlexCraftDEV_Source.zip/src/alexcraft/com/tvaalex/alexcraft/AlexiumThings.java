package com.tvaalex.alexcraft;

import com.tvaalex.alexcraft.blocks.ACBlock;
import com.tvaalex.alexcraft.items.ACIngot;
import com.tvaalex.alexcraft.items.ACItem;
import com.tvaalex.alexcraft.items.armor.ACArmor;
import com.tvaalex.alexcraft.items.tools.ACAxe;
import com.tvaalex.alexcraft.items.tools.ACHammer;
import com.tvaalex.alexcraft.items.tools.ACHoe;
import com.tvaalex.alexcraft.items.tools.ACMultiTool;
import com.tvaalex.alexcraft.items.tools.ACPick;
import com.tvaalex.alexcraft.items.tools.ACShovel;
import com.tvaalex.alexcraft.items.tools.ACSword;

import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemArmor.ArmorMaterial;
import net.minecraftforge.common.util.EnumHelper;

public class AlexiumThings {
		//Alexium Declarations
		//Items and Blocks
		public static Item itemAlexiumIngot;
		public static Item itemAlexiumHeavyIngot;
		public static Item itemAlexiumStick;
		public static Block blockAlexiumBlock;
		public static Block blockAlexiumOre;
		//Materials
		public static final Item.ToolMaterial alexiumToolMaterial = EnumHelper.addToolMaterial("AlexiumToolMaterial", 4, 2000, 9.0F, 5.5F, 80);   
		public static final ArmorMaterial alexiumArmorMaterial = EnumHelper.addArmorMaterial("AlexiumArmorMaterial", 9, new int[]{5, 7, 5, 3}, 80);
		//Tools
		public static Item alexiumPickaxe;
		public static Item alexiumSword;
		public static Item alexiumAxe;
		public static Item alexiumShovel;
		public static Item alexiumHoe;
		public static Item alexiumMultiTool;
		public static Item alexiumHammer;
		//Armors
		public static Item alexiumHelmet;
		public static Item alexiumChestplate;
		public static Item alexiumLeggings;
		public static Item alexiumBoots;
		
		public static void LoadAll() {
			//Alexium Items and Block Init.
				//Alexium Registry
				GameRegistry.registerItem(itemAlexiumIngot = new ACIngot().setUnlocalizedName("ItemAlexiumIngot"), itemAlexiumIngot.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(itemAlexiumHeavyIngot = new ACIngot().setUnlocalizedName("ItemAlexiumHeavyIngot"), itemAlexiumHeavyIngot.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(itemAlexiumStick = new ACItem().setUnlocalizedName("ItemAlexiumStick"), itemAlexiumStick.getUnlocalizedName().substring(5));
				GameRegistry.registerBlock(blockAlexiumBlock = new ACBlock(Material.iron, 2, 10.0F, 1000.0F).setBlockName("BlockAlexiumBlock").setBlockTextureName(AlexCraft.modid + ":BlockAlexiumBlock"), blockAlexiumBlock.getUnlocalizedName().substring(5));
				GameRegistry.registerBlock(blockAlexiumOre = new ACBlock(Material.rock, 3, 25.0F, 1500.0F).setBlockName("BlockAlexiumOre").setBlockTextureName(AlexCraft.modid + ":BlockAlexiumOre"), blockAlexiumOre.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(alexiumPickaxe = new ACPick("AlexiumPickaxe", alexiumToolMaterial), alexiumPickaxe.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(alexiumSword = new ACSword("AlexiumSword", alexiumToolMaterial), alexiumSword.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(alexiumAxe = new ACAxe("AlexiumAxe", alexiumToolMaterial), alexiumAxe.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(alexiumShovel = new ACShovel("AlexiumShovel", alexiumToolMaterial), alexiumShovel.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(alexiumHoe = new ACHoe("AlexiumHoe", alexiumToolMaterial), alexiumHoe.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(alexiumMultiTool = new ACMultiTool("AlexiumMultiTool", alexiumToolMaterial), alexiumMultiTool.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(alexiumHammer = new ACHammer("AlexiumHammer", alexiumToolMaterial), alexiumHammer.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(alexiumHelmet = new ACArmor("AlexiumHelmet", alexiumArmorMaterial, "AlexiumArmor", 0), alexiumHelmet.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(alexiumChestplate = new ACArmor("AlexiumChestplate", alexiumArmorMaterial, "AlexiumArmor", 1), alexiumChestplate.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(alexiumLeggings = new ACArmor("AlexiumLeggings", alexiumArmorMaterial, "AlexiumArmor", 2), alexiumLeggings.getUnlocalizedName().substring(5));
				GameRegistry.registerItem(alexiumBoots = new ACArmor("AlexiumBoots", alexiumArmorMaterial, "AlexiumArmor", 3), alexiumBoots.getUnlocalizedName().substring(5));				
				//Alexium Crafting Recipies
				//Blocks and Items
				GameRegistry.addRecipe(new ItemStack(itemAlexiumStick), new Object[] {"   ", "X#X", "   ", 'X', itemAlexiumIngot, '#', Items.stick});
				GameRegistry.addRecipe(new ItemStack(alexiumPickaxe), new Object[] {"XXX", " # ", " # ", 'X', itemAlexiumIngot, '#', itemAlexiumStick});
				GameRegistry.addRecipe(new ItemStack(alexiumAxe), new Object[] {"XX ", "X# ", " # ", 'X', itemAlexiumIngot, '#', itemAlexiumStick});
				GameRegistry.addRecipe(new ItemStack(alexiumSword), new Object[] {" X ", " X ", " # ", 'X', itemAlexiumIngot, '#', itemAlexiumStick});
				GameRegistry.addRecipe(new ItemStack(alexiumShovel), new Object[] {" X ", " # ", " # ", 'X', itemAlexiumIngot, '#', itemAlexiumStick});
				GameRegistry.addRecipe(new ItemStack(alexiumHoe), new Object[] {" XX", " # ", " # ", 'X', itemAlexiumIngot, '#', itemAlexiumStick});
				GameRegistry.addRecipe(new ItemStack(alexiumMultiTool), new Object[] {"ZXZ", " # ", " # ", 'X', itemAlexiumIngot, '#', itemAlexiumStick, 'Z', blockAlexiumBlock});
				GameRegistry.addRecipe(new ItemStack(blockAlexiumBlock), new Object[] {"XXX", "XXX", "XXX", 'X', itemAlexiumIngot});
				GameRegistry.addShapelessRecipe(new ItemStack(itemAlexiumIngot, 9), new Object[] {blockAlexiumBlock});
				GameRegistry.addRecipe(new ItemStack(itemAlexiumHeavyIngot), new Object[] {"   ", " XX", " XX", 'X', itemAlexiumIngot});
				GameRegistry.addShapelessRecipe(new ItemStack(itemAlexiumIngot, 4), new Object[] {itemAlexiumHeavyIngot});
				GameRegistry.addRecipe(new ItemStack(alexiumHelmet), new Object[] {"XXX", "X X", "   ", 'X', itemAlexiumIngot});
				GameRegistry.addRecipe(new ItemStack(alexiumChestplate), new Object[] {"X X", "XXX", "XXX", 'X', itemAlexiumIngot});
				GameRegistry.addRecipe(new ItemStack(alexiumLeggings), new Object[] {"XXX", "X X", "X X", 'X', itemAlexiumIngot});
				GameRegistry.addRecipe(new ItemStack(alexiumBoots), new Object[] {"   ", "X X", "X X", 'X', itemAlexiumIngot});
				//Alexium Smelting Recipies
				GameRegistry.addSmelting(blockAlexiumOre, new ItemStack(itemAlexiumIngot), 0.5F);

					
		}

}
