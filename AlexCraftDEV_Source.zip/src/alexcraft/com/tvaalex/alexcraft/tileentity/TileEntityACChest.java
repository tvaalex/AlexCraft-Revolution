package com.tvaalex.alexcraft.tileentity;

import net.minecraft.tileentity.TileEntityChest;

public class TileEntityACChest extends TileEntityChest{

}
